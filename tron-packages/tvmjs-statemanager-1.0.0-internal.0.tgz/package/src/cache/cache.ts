import { isDebugEnabled } from '@tvmjs/util'
import debugDefault from 'debug'

import type { Debugger } from 'debug'

export class Cache {
  _debug: Debugger

  _checkpoints = 0

  _stats = {
    size: 0,
    reads: 0,
    hits: 0,
    writes: 0,
    deletions: 0,
  }

  /**
   * StateManager cache is run in DEBUG mode (default: false)
   * Taken from DEBUG environment variable
   *
   * Safeguards on debug() calls are added for
   * performance reasons to avoid string literal evaluation
   * @hidden
   */
  protected readonly DEBUG: boolean = false

  constructor() {
    // Skip DEBUG calls unless 'tvmjs' included in environmental DEBUG variables
    this.DEBUG = isDebugEnabled('tvmjs')

    this._debug = debugDefault('statemanager:cache')
  }
}
