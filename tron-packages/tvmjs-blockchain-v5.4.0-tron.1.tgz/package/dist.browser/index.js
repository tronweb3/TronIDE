"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var debug_1 = require("debug");
var semaphore_async_await_1 = __importDefault(require("semaphore-async-await"));
var util_1 = require("@tvmjs/util");
var block_1 = require("@tvmjs/block");
var common_1 = __importDefault(require("@tvmjs/common"));
var manager_1 = require("./db/manager");
var helpers_1 = require("./db/helpers");
var operation_1 = require("./db/operation");
// eslint-disable-next-line @typescript-eslint/no-unused-vars,no-unused-vars
var debug = debug_1.debug('blockchain');
var level = require('level-mem');
/**
 * This class stores and interacts with blocks.
 */
var Blockchain = /** @class */ (function () {
    /**
     * Creates new Blockchain object
     *
     * @deprecated - The direct usage of this constructor is discouraged since
     * non-finalized async initialization might lead to side effects. Please
     * use the async {@link Blockchain.create} constructor instead (same API).
     *
     * @param opts - An object with the options that this constructor takes. See
     * {@link BlockchainOptions}.
     */
    function Blockchain(opts) {
        if (opts === void 0) { opts = {}; }
        var _a, _b, _c;
        // Throw on chain or hardfork options removed in latest major release to
        // prevent implicit chain setup on a wrong chain
        if ('chain' in opts || 'hardfork' in opts) {
            throw new Error('Chain/hardfork options are not allowed any more on initialization');
        }
        if (opts.common) {
            this._common = opts.common;
        }
        else {
            var DEFAULT_CHAIN = 'mainnet';
            var DEFAULT_HARDFORK = 'tron';
            this._common = new common_1.default({
                chain: DEFAULT_CHAIN,
                hardfork: DEFAULT_HARDFORK,
            });
        }
        this._hardforkByHeadBlockNumber = (_a = opts.hardforkByHeadBlockNumber) !== null && _a !== void 0 ? _a : false;
        this._validateConsensus = (_b = opts.validateConsensus) !== null && _b !== void 0 ? _b : true;
        this._validateBlocks = (_c = opts.validateBlocks) !== null && _c !== void 0 ? _c : true;
        this.db = opts.db ? opts.db : level();
        this.dbManager = new manager_1.DBManager(this.db, this._common);
        this._heads = {};
        this._lock = new semaphore_async_await_1.default(1);
        if (opts.genesisBlock && !opts.genesisBlock.isGenesis()) {
            throw 'supplied block is not a genesis block';
        }
        // eslint-disable-next-line @typescript-eslint/no-floating-promises
        this.initPromise = this._init(opts.genesisBlock);
    }
    /**
     * Safe creation of a new Blockchain object awaiting the initialization function,
     * encouraged method to use when creating a blockchain object.
     *
     * @param opts Constructor options, see {@link BlockchainOptions}
     */
    Blockchain.create = function (opts) {
        if (opts === void 0) { opts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var blockchain;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        blockchain = new Blockchain(opts);
                        return [4 /*yield*/, blockchain.initPromise.catch(function (e) {
                                throw e;
                            })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, blockchain];
                }
            });
        });
    };
    /**
     * Creates a blockchain from a list of block objects,
     * objects must be readable by {@link Block.fromBlockData}
     *
     * @param blockData List of block objects
     * @param opts Constructor options, see {@link BlockchainOptions}
     */
    Blockchain.fromBlocksData = function (blocksData, opts) {
        if (opts === void 0) { opts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var blockchain, blocksData_1, blocksData_1_1, blockData, block, e_1_1;
            var e_1, _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, Blockchain.create(opts)];
                    case 1:
                        blockchain = _b.sent();
                        _b.label = 2;
                    case 2:
                        _b.trys.push([2, 7, 8, 9]);
                        blocksData_1 = __values(blocksData), blocksData_1_1 = blocksData_1.next();
                        _b.label = 3;
                    case 3:
                        if (!!blocksData_1_1.done) return [3 /*break*/, 6];
                        blockData = blocksData_1_1.value;
                        block = block_1.Block.fromBlockData(blockData, {
                            common: blockchain._common,
                            hardforkByBlockNumber: true,
                        });
                        return [4 /*yield*/, blockchain.putBlock(block)];
                    case 4:
                        _b.sent();
                        _b.label = 5;
                    case 5:
                        blocksData_1_1 = blocksData_1.next();
                        return [3 /*break*/, 3];
                    case 6: return [3 /*break*/, 9];
                    case 7:
                        e_1_1 = _b.sent();
                        e_1 = { error: e_1_1 };
                        return [3 /*break*/, 9];
                    case 8:
                        try {
                            if (blocksData_1_1 && !blocksData_1_1.done && (_a = blocksData_1.return)) _a.call(blocksData_1);
                        }
                        finally { if (e_1) throw e_1.error; }
                        return [7 /*endfinally*/];
                    case 9: return [2 /*return*/, blockchain];
                }
            });
        });
    };
    Object.defineProperty(Blockchain.prototype, "meta", {
        /**
         * Returns an object with metadata about the Blockchain. It's defined for
         * backwards compatibility.
         */
        get: function () {
            return {
                rawHead: this._headHeaderHash,
                heads: this._heads,
                genesis: this._genesis,
            };
        },
        enumerable: false,
        configurable: true
    });
    /**
     * This method is called in the constructor and either sets up the DB or reads
     * values from the DB and makes these available to the consumers of
     * Blockchain.
     *
     * @hidden
     */
    Blockchain.prototype._init = function (genesisBlock) {
        return __awaiter(this, void 0, void 0, function () {
            var dbGenesisBlock, genesisHash_1, error_1, common, genesisHash, dbOps_1, heads, error_2, hash, error_3, hash, error_4, latestHeader;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 3, , 4]);
                        return [4 /*yield*/, this.dbManager.numberToHash(new util_1.BN(0))];
                    case 1:
                        genesisHash_1 = _a.sent();
                        return [4 /*yield*/, this.dbManager.getBlock(genesisHash_1)];
                    case 2:
                        dbGenesisBlock = _a.sent();
                        return [3 /*break*/, 4];
                    case 3:
                        error_1 = _a.sent();
                        if (error_1.type !== 'NotFoundError') {
                            throw error_1;
                        }
                        return [3 /*break*/, 4];
                    case 4:
                        if (!genesisBlock) {
                            common = this._common.copy();
                            common.setHardfork('chainstart');
                            genesisBlock = block_1.Block.genesis({}, { common: common });
                        }
                        // If the DB has a genesis block, then verify that the genesis block in the
                        // DB is indeed the Genesis block generated or assigned.
                        if (dbGenesisBlock && !genesisBlock.hash().equals(dbGenesisBlock.hash())) {
                            throw new Error('The genesis block in the DB has a different hash than the provided genesis block.');
                        }
                        genesisHash = genesisBlock.hash();
                        if (!!dbGenesisBlock) return [3 /*break*/, 6];
                        dbOps_1 = [];
                        helpers_1.DBSetBlockOrHeader(genesisBlock).map(function (op) { return dbOps_1.push(op); });
                        helpers_1.DBSaveLookups(genesisHash, new util_1.BN(0)).map(function (op) { return dbOps_1.push(op); });
                        return [4 /*yield*/, this.dbManager.batch(dbOps_1)];
                    case 5:
                        _a.sent();
                        _a.label = 6;
                    case 6:
                        // At this point, we can safely set genesisHash as the _genesis hash in this
                        // object: it is either the one we put in the DB, or it is equal to the one
                        // which we read from the DB.
                        this._genesis = genesisHash;
                        _a.label = 7;
                    case 7:
                        _a.trys.push([7, 9, , 10]);
                        return [4 /*yield*/, this.dbManager.getHeads()];
                    case 8:
                        heads = _a.sent();
                        this._heads = heads;
                        return [3 /*break*/, 10];
                    case 9:
                        error_2 = _a.sent();
                        if (error_2.type !== 'NotFoundError') {
                            throw error_2;
                        }
                        this._heads = {};
                        return [3 /*break*/, 10];
                    case 10:
                        _a.trys.push([10, 12, , 13]);
                        return [4 /*yield*/, this.dbManager.getHeadHeader()];
                    case 11:
                        hash = _a.sent();
                        this._headHeaderHash = hash;
                        return [3 /*break*/, 13];
                    case 12:
                        error_3 = _a.sent();
                        if (error_3.type !== 'NotFoundError') {
                            throw error_3;
                        }
                        this._headHeaderHash = genesisHash;
                        return [3 /*break*/, 13];
                    case 13:
                        _a.trys.push([13, 15, , 16]);
                        return [4 /*yield*/, this.dbManager.getHeadBlock()];
                    case 14:
                        hash = _a.sent();
                        this._headBlockHash = hash;
                        return [3 /*break*/, 16];
                    case 15:
                        error_4 = _a.sent();
                        if (error_4.type !== 'NotFoundError') {
                            throw error_4;
                        }
                        this._headBlockHash = genesisHash;
                        return [3 /*break*/, 16];
                    case 16:
                        if (!this._hardforkByHeadBlockNumber) return [3 /*break*/, 18];
                        return [4 /*yield*/, this._getHeader(this._headHeaderHash)];
                    case 17:
                        latestHeader = _a.sent();
                        this._common.setHardforkByBlockNumber(latestHeader.number);
                        _a.label = 18;
                    case 18: return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Perform the `action` function after we have initialized this module and
     * have acquired a lock
     * @param action - the action function to run after initializing and acquiring
     * a lock
     * @hidden
     */
    Blockchain.prototype.initAndLock = function (action) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.initPromise];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, this.runWithLock(action)];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    /**
     * Run a function after acquiring a lock. It is implied that we have already
     * initialized the module (or we are calling this from the init function, like
     * `_setCanonicalGenesisBlock`)
     * @param action - function to run after acquiring a lock
     * @hidden
     */
    Blockchain.prototype.runWithLock = function (action) {
        return __awaiter(this, void 0, void 0, function () {
            var value;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, , 3, 4]);
                        return [4 /*yield*/, this._lock.acquire()];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, action()];
                    case 2:
                        value = _a.sent();
                        return [2 /*return*/, value];
                    case 3:
                        this._lock.release();
                        return [7 /*endfinally*/];
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Returns the specified iterator head.
     *
     * This function replaces the old {@link Blockchain.getHead} method. Note that
     * the function deviates from the old behavior and returns the
     * genesis hash instead of the current head block if an iterator
     * has not been run. This matches the behavior of {@link Blockchain.iterator}.
     *
     * @param name - Optional name of the iterator head (default: 'vm')
     */
    Blockchain.prototype.getIteratorHead = function (name) {
        if (name === void 0) { name = 'vm'; }
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.initAndLock(function () { return __awaiter(_this, void 0, void 0, function () {
                            var hash, block;
                            return __generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0:
                                        hash = this._heads[name] || this._genesis;
                                        if (!hash) {
                                            throw new Error('No head found.');
                                        }
                                        return [4 /*yield*/, this._getBlock(hash)];
                                    case 1:
                                        block = _a.sent();
                                        return [2 /*return*/, block];
                                }
                            });
                        }); })];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    /**
     * Returns the specified iterator head.
     *
     * @param name - Optional name of the iterator head (default: 'vm')
     *
     * @deprecated use {@link Blockchain.getIteratorHead} instead.
     * Note that {@link Blockchain.getIteratorHead} doesn't return
     * the `headHeader` but the genesis hash as an initial iterator
     * head value (now matching the behavior of {@link Blockchain.iterator}
     * on a first run)
     */
    Blockchain.prototype.getHead = function (name) {
        if (name === void 0) { name = 'vm'; }
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.initAndLock(function () { return __awaiter(_this, void 0, void 0, function () {
                            var hash, block;
                            return __generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0:
                                        hash = this._heads[name] || this._headBlockHash;
                                        if (!hash) {
                                            throw new Error('No head found.');
                                        }
                                        return [4 /*yield*/, this._getBlock(hash)];
                                    case 1:
                                        block = _a.sent();
                                        return [2 /*return*/, block];
                                }
                            });
                        }); })];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    /**
     * Returns the latest header in the canonical chain.
     */
    Blockchain.prototype.getLatestHeader = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.initAndLock(function () { return __awaiter(_this, void 0, void 0, function () {
                            var block;
                            return __generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0:
                                        if (!this._headHeaderHash) {
                                            throw new Error('No head header set');
                                        }
                                        return [4 /*yield*/, this._getBlock(this._headHeaderHash)];
                                    case 1:
                                        block = _a.sent();
                                        return [2 /*return*/, block.header];
                                }
                            });
                        }); })];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    /**
     * Returns the latest full block in the canonical chain.
     */
    Blockchain.prototype.getLatestBlock = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            return __generator(this, function (_a) {
                return [2 /*return*/, this.initAndLock(function () { return __awaiter(_this, void 0, void 0, function () {
                        var block;
                        return __generator(this, function (_a) {
                            if (!this._headBlockHash) {
                                throw new Error('No head block set');
                            }
                            block = this._getBlock(this._headBlockHash);
                            return [2 /*return*/, block];
                        });
                    }); })];
            });
        });
    };
    /**
     * Adds blocks to the blockchain.
     *
     * If an invalid block is met the function will throw, blocks before will
     * nevertheless remain in the DB. If any of the saved blocks has a higher
     * total difficulty than the current max total difficulty the canonical
     * chain is rebuilt and any stale heads/hashes are overwritten.
     * @param blocks - The blocks to be added to the blockchain
     */
    Blockchain.prototype.putBlocks = function (blocks) {
        return __awaiter(this, void 0, void 0, function () {
            var i;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.initPromise];
                    case 1:
                        _a.sent();
                        i = 0;
                        _a.label = 2;
                    case 2:
                        if (!(i < blocks.length)) return [3 /*break*/, 5];
                        return [4 /*yield*/, this.putBlock(blocks[i])];
                    case 3:
                        _a.sent();
                        _a.label = 4;
                    case 4:
                        i++;
                        return [3 /*break*/, 2];
                    case 5: return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Adds a block to the blockchain.
     *
     * If the block is valid and has a higher total difficulty than the current
     * max total difficulty, the canonical chain is rebuilt and any stale
     * heads/hashes are overwritten.
     * @param block - The block to be added to the blockchain
     */
    Blockchain.prototype.putBlock = function (block) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.initPromise];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, this._putBlockOrHeader(block)];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Adds many headers to the blockchain.
     *
     * If an invalid header is met the function will throw, headers before will
     * nevertheless remain in the DB. If any of the saved headers has a higher
     * total difficulty than the current max total difficulty the canonical
     * chain is rebuilt and any stale heads/hashes are overwritten.
     * @param headers - The headers to be added to the blockchain
     */
    Blockchain.prototype.putHeaders = function (headers) {
        return __awaiter(this, void 0, void 0, function () {
            var i;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.initPromise];
                    case 1:
                        _a.sent();
                        i = 0;
                        _a.label = 2;
                    case 2:
                        if (!(i < headers.length)) return [3 /*break*/, 5];
                        return [4 /*yield*/, this.putHeader(headers[i])];
                    case 3:
                        _a.sent();
                        _a.label = 4;
                    case 4:
                        i++;
                        return [3 /*break*/, 2];
                    case 5: return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Adds a header to the blockchain.
     *
     * If this header is valid and it has a higher total difficulty than the current
     * max total difficulty, the canonical chain is rebuilt and any stale
     * heads/hashes are overwritten.
     * @param header - The header to be added to the blockchain
     */
    Blockchain.prototype.putHeader = function (header) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.initPromise];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, this._putBlockOrHeader(header)];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Entrypoint for putting any block or block header. Verifies this block,
     * checks the total TD: if this TD is higher than the current highest TD, we
     * have thus found a new canonical block and have to rewrite the canonical
     * chain. This also updates the head block hashes. If any of the older known
     * canonical chains just became stale, then we also reset every _heads header
     * which points to a stale header to the last verified header which was in the
     * old canonical chain, but also in the new canonical chain. This thus rolls
     * back these headers so that these can be updated to the "new" canonical
     * header using the iterator method.
     * @hidden
     */
    Blockchain.prototype._putBlockOrHeader = function (item) {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.runWithLock(function () { return __awaiter(_this, void 0, void 0, function () {
                            var block, isGenesis, isHeader, header, blockHash, blockNumber, dbOps, isLatestNumber, error_5, ops;
                            return __generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0:
                                        block = item instanceof block_1.BlockHeader
                                            ? new block_1.Block(item, undefined, {
                                                common: this._common,
                                                hardforkByBlockNumber: true,
                                            })
                                            : item;
                                        isGenesis = block.isGenesis();
                                        isHeader = item instanceof block_1.BlockHeader;
                                        // we cannot overwrite the Genesis block after initializing the Blockchain
                                        if (isGenesis) {
                                            throw new Error('Cannot put a genesis block: create a new Blockchain');
                                        }
                                        header = block.header;
                                        blockHash = header.hash();
                                        blockNumber = header.number;
                                        dbOps = [];
                                        if (!block._common.chainIdBN().eq(this._common.chainIdBN())) {
                                            throw new Error('Chain mismatch while trying to put block or header');
                                        }
                                        if (!this._validateBlocks) return [3 /*break*/, 2];
                                        // this calls into `getBlock`, which is why we cannot lock yet
                                        return [4 /*yield*/, block.validate(this, isHeader)];
                                    case 1:
                                        // this calls into `getBlock`, which is why we cannot lock yet
                                        _a.sent();
                                        _a.label = 2;
                                    case 2:
                                        // save header/block to the database
                                        dbOps = dbOps.concat(helpers_1.DBSetBlockOrHeader(block));
                                        isLatestNumber = true;
                                        _a.label = 3;
                                    case 3:
                                        _a.trys.push([3, 5, , 6]);
                                        return [4 /*yield*/, this.getBlock(blockNumber.addn(1))];
                                    case 4:
                                        _a.sent();
                                        isLatestNumber = false;
                                        return [3 /*break*/, 6];
                                    case 5:
                                        error_5 = _a.sent();
                                        return [3 /*break*/, 6];
                                    case 6:
                                        if (!isLatestNumber) return [3 /*break*/, 9];
                                        this._headHeaderHash = blockHash;
                                        if (item instanceof block_1.Block) {
                                            this._headBlockHash = blockHash;
                                        }
                                        if (this._hardforkByHeadBlockNumber) {
                                            this._common.setHardforkByBlockNumber(blockNumber);
                                        }
                                        // delete higher number assignments and overwrite stale canonical chain
                                        return [4 /*yield*/, this._deleteCanonicalChainReferences(blockNumber.addn(1), blockHash, dbOps)
                                            // from the current header block, check the blockchain in reverse (i.e.
                                            // traverse `parentHash`) until `numberToHash` matches the current
                                            // number/hash in the canonical chain also: overwrite any heads if these
                                            // heads are stale in `_heads` and `_headBlockHash`
                                        ];
                                    case 7:
                                        // delete higher number assignments and overwrite stale canonical chain
                                        _a.sent();
                                        // from the current header block, check the blockchain in reverse (i.e.
                                        // traverse `parentHash`) until `numberToHash` matches the current
                                        // number/hash in the canonical chain also: overwrite any heads if these
                                        // heads are stale in `_heads` and `_headBlockHash`
                                        return [4 /*yield*/, this._rebuildCanonical(header, dbOps)];
                                    case 8:
                                        // from the current header block, check the blockchain in reverse (i.e.
                                        // traverse `parentHash`) until `numberToHash` matches the current
                                        // number/hash in the canonical chain also: overwrite any heads if these
                                        // heads are stale in `_heads` and `_headBlockHash`
                                        _a.sent();
                                        return [3 /*break*/, 10];
                                    case 9:
                                        if (item instanceof block_1.Block) {
                                            this._headBlockHash = blockHash;
                                        }
                                        // save hash to number lookup info even if rebuild not needed
                                        dbOps.push(helpers_1.DBSetHashToNumber(blockHash, blockNumber));
                                        _a.label = 10;
                                    case 10:
                                        ops = dbOps.concat(this._saveHeadOps());
                                        return [4 /*yield*/, this.dbManager.batch(ops)];
                                    case 11:
                                        _a.sent();
                                        return [2 /*return*/];
                                }
                            });
                        }); })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Gets a block by its hash.
     *
     * @param blockId - The block's hash or number. If a hash is provided, then
     * this will be immediately looked up, otherwise it will wait until we have
     * unlocked the DB
     */
    Blockchain.prototype.getBlock = function (blockId) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: 
                    // cannot wait for a lock here: it is used both in `validate` of `Block`
                    // (calls `getBlock` to get `parentHash`) it is also called from `runBlock`
                    // in the `VM` if we encounter a `BLOCKHASH` opcode: then a BN is used we
                    // need to then read the block from the canonical chain Q: is this safe? We
                    // know it is OK if we call it from the iterator... (runBlock)
                    return [4 /*yield*/, this.initPromise];
                    case 1:
                        // cannot wait for a lock here: it is used both in `validate` of `Block`
                        // (calls `getBlock` to get `parentHash`) it is also called from `runBlock`
                        // in the `VM` if we encounter a `BLOCKHASH` opcode: then a BN is used we
                        // need to then read the block from the canonical chain Q: is this safe? We
                        // know it is OK if we call it from the iterator... (runBlock)
                        _a.sent();
                        return [4 /*yield*/, this._getBlock(blockId)];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    /**
     * @hidden
     */
    Blockchain.prototype._getBlock = function (blockId) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this.dbManager.getBlock(blockId)];
            });
        });
    };
    /**
     * Looks up many blocks relative to blockId Note: due to `GetBlockHeaders
     * (0x03)` (ETH wire protocol) we have to support skip/reverse as well.
     * @param blockId - The block's hash or number
     * @param maxBlocks - Max number of blocks to return
     * @param skip - Number of blocks to skip apart
     * @param reverse - Fetch blocks in reverse
     */
    Blockchain.prototype.getBlocks = function (blockId, maxBlocks, skip, reverse) {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.initAndLock(function () { return __awaiter(_this, void 0, void 0, function () {
                            var blocks, i, nextBlock;
                            var _this = this;
                            return __generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0:
                                        blocks = [];
                                        i = -1;
                                        nextBlock = function (blockId) { return __awaiter(_this, void 0, void 0, function () {
                                            var block, error_6, nextBlockNumber;
                                            return __generator(this, function (_a) {
                                                switch (_a.label) {
                                                    case 0:
                                                        _a.trys.push([0, 2, , 3]);
                                                        return [4 /*yield*/, this._getBlock(blockId)];
                                                    case 1:
                                                        block = _a.sent();
                                                        return [3 /*break*/, 3];
                                                    case 2:
                                                        error_6 = _a.sent();
                                                        if (error_6.type !== 'NotFoundError') {
                                                            throw error_6;
                                                        }
                                                        return [2 /*return*/];
                                                    case 3:
                                                        i++;
                                                        nextBlockNumber = block.header.number.addn(reverse ? -1 : 1);
                                                        if (!(i !== 0 && skip && i % (skip + 1) !== 0)) return [3 /*break*/, 5];
                                                        return [4 /*yield*/, nextBlock(nextBlockNumber)];
                                                    case 4: return [2 /*return*/, _a.sent()];
                                                    case 5:
                                                        blocks.push(block);
                                                        if (!(blocks.length < maxBlocks)) return [3 /*break*/, 7];
                                                        return [4 /*yield*/, nextBlock(nextBlockNumber)];
                                                    case 6:
                                                        _a.sent();
                                                        _a.label = 7;
                                                    case 7: return [2 /*return*/];
                                                }
                                            });
                                        }); };
                                        return [4 /*yield*/, nextBlock(blockId)];
                                    case 1:
                                        _a.sent();
                                        return [2 /*return*/, blocks];
                                }
                            });
                        }); })];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    /**
     * Given an ordered array, returns an array of hashes that are not in the
     * blockchain yet. Uses binary search to find out what hashes are missing.
     * Therefore, the array needs to be ordered upon number.
     * @param hashes - Ordered array of hashes (ordered on `number`).
     */
    Blockchain.prototype.selectNeededHashes = function (hashes) {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.initAndLock(function () { return __awaiter(_this, void 0, void 0, function () {
                            var max, mid, min, number, error_7;
                            return __generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0:
                                        max = hashes.length - 1;
                                        mid = min = 0;
                                        _a.label = 1;
                                    case 1:
                                        if (!(max >= min)) return [3 /*break*/, 6];
                                        number = void 0;
                                        _a.label = 2;
                                    case 2:
                                        _a.trys.push([2, 4, , 5]);
                                        return [4 /*yield*/, this.dbManager.hashToNumber(hashes[mid])];
                                    case 3:
                                        number = _a.sent();
                                        return [3 /*break*/, 5];
                                    case 4:
                                        error_7 = _a.sent();
                                        if (error_7.type !== 'NotFoundError') {
                                            throw error_7;
                                        }
                                        return [3 /*break*/, 5];
                                    case 5:
                                        if (number) {
                                            min = mid + 1;
                                        }
                                        else {
                                            max = mid - 1;
                                        }
                                        mid = Math.floor((min + max) / 2);
                                        return [3 /*break*/, 1];
                                    case 6: return [2 /*return*/, hashes.slice(min)];
                                }
                            });
                        }); })];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    /**
     * Completely deletes a block from the blockchain including any references to
     * this block. If this block was in the canonical chain, then also each child
     * block of this block is deleted Also, if this was a canonical block, each
     * head header which is part of this now stale chain will be set to the
     * parentHeader of this block An example reason to execute is when running the
     * block in the VM invalidates this block: this will then reset the canonical
     * head to the past block (which has been validated in the past by the VM, so
     * we can be sure it is correct).
     * @param blockHash - The hash of the block to be deleted
     */
    Blockchain.prototype.delBlock = function (blockHash) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: 
                    // Q: is it safe to make this not wait for a lock? this is called from
                    // `runBlockchain` in case `runBlock` throws (i.e. the block is invalid).
                    // But is this the way to go? If we know this is called from the
                    // iterator/runBlockchain we are safe, but if this is called from anywhere
                    // else then this might lead to a concurrency problem?
                    return [4 /*yield*/, this.initPromise];
                    case 1:
                        // Q: is it safe to make this not wait for a lock? this is called from
                        // `runBlockchain` in case `runBlock` throws (i.e. the block is invalid).
                        // But is this the way to go? If we know this is called from the
                        // iterator/runBlockchain we are safe, but if this is called from anywhere
                        // else then this might lead to a concurrency problem?
                        _a.sent();
                        return [4 /*yield*/, this._delBlock(blockHash)];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * @hidden
     */
    Blockchain.prototype._delBlock = function (blockHash) {
        return __awaiter(this, void 0, void 0, function () {
            var dbOps, header, blockHeader, blockNumber, parentHash, canonicalHash, inCanonical;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        dbOps = [];
                        return [4 /*yield*/, this._getHeader(blockHash)];
                    case 1:
                        header = _a.sent();
                        blockHeader = header;
                        blockNumber = blockHeader.number;
                        parentHash = blockHeader.parentHash;
                        return [4 /*yield*/, this.safeNumberToHash(blockNumber)];
                    case 2:
                        canonicalHash = _a.sent();
                        inCanonical = !!canonicalHash && canonicalHash.equals(blockHash);
                        // delete the block, and if block is in the canonical chain, delete all
                        // children as well
                        return [4 /*yield*/, this._delChild(blockHash, blockNumber, inCanonical ? parentHash : null, dbOps)
                            // delete all number to hash mappings for deleted block number and above
                        ];
                    case 3:
                        // delete the block, and if block is in the canonical chain, delete all
                        // children as well
                        _a.sent();
                        if (!inCanonical) return [3 /*break*/, 5];
                        return [4 /*yield*/, this._deleteCanonicalChainReferences(blockNumber, parentHash, dbOps)];
                    case 4:
                        _a.sent();
                        _a.label = 5;
                    case 5: return [4 /*yield*/, this.dbManager.batch(dbOps)];
                    case 6:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Updates the `DatabaseOperation` list to delete a block from the DB,
     * identified by `blockHash` and `blockNumber`. Deletes fields from `Header`,
     * `Body`, `HashToNumber` and `TotalDifficulty` tables. If child blocks of
     * this current block are in the canonical chain, delete these as well. Does
     * not actually commit these changes to the DB. Sets `_headHeaderHash` and
     * `_headBlockHash` to `headHash` if any of these matches the current child to
     * be deleted.
     * @param blockHash - the block hash to delete
     * @param blockNumber - the number corresponding to the block hash
     * @param headHash - the current head of the chain (if null, do not update
     * `_headHeaderHash` and `_headBlockHash`)
     * @param ops - the `DatabaseOperation` list to add the delete operations to
     * @hidden
     */
    Blockchain.prototype._delChild = function (blockHash, blockNumber, headHash, ops) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function () {
            var childHeader, error_8;
            return __generator(this, function (_c) {
                switch (_c.label) {
                    case 0:
                        // delete header, body, hash to number mapping and td
                        ops.push(helpers_1.DBOp.del(operation_1.DBTarget.Header, { blockHash: blockHash, blockNumber: blockNumber }));
                        ops.push(helpers_1.DBOp.del(operation_1.DBTarget.Body, { blockHash: blockHash, blockNumber: blockNumber }));
                        ops.push(helpers_1.DBOp.del(operation_1.DBTarget.HashToNumber, { blockHash: blockHash }));
                        ops.push(helpers_1.DBOp.del(operation_1.DBTarget.TotalDifficulty, { blockHash: blockHash, blockNumber: blockNumber }));
                        if (!headHash) {
                            return [2 /*return*/];
                        }
                        if ((_a = this._headHeaderHash) === null || _a === void 0 ? void 0 : _a.equals(blockHash)) {
                            this._headHeaderHash = headHash;
                        }
                        if ((_b = this._headBlockHash) === null || _b === void 0 ? void 0 : _b.equals(blockHash)) {
                            this._headBlockHash = headHash;
                        }
                        _c.label = 1;
                    case 1:
                        _c.trys.push([1, 4, , 5]);
                        return [4 /*yield*/, this._getCanonicalHeader(blockNumber.addn(1))];
                    case 2:
                        childHeader = _c.sent();
                        return [4 /*yield*/, this._delChild(childHeader.hash(), childHeader.number, headHash, ops)];
                    case 3:
                        _c.sent();
                        return [3 /*break*/, 5];
                    case 4:
                        error_8 = _c.sent();
                        if (error_8.type !== 'NotFoundError') {
                            throw error_8;
                        }
                        return [3 /*break*/, 5];
                    case 5: return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Iterates through blocks starting at the specified iterator head and calls
     * the onBlock function on each block. The current location of an iterator
     * head can be retrieved using {@link Blockchain.getIteratorHead}.
     *
     * @param name - Name of the state root head
     * @param onBlock - Function called on each block with params (block, reorg)
     * @param maxBlocks - How many blocks to run. By default, run all unprocessed blocks in the canonical chain.
     * @returns number of blocks actually iterated
     */
    Blockchain.prototype.iterator = function (name, onBlock, maxBlocks) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this._iterator(name, onBlock, maxBlocks)];
            });
        });
    };
    /**
     * @hidden
     */
    Blockchain.prototype._iterator = function (name, onBlock, maxBlocks) {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.initAndLock(function () { return __awaiter(_this, void 0, void 0, function () {
                            var headHash, lastBlock, headBlockNumber, nextBlockNumber, blocksRanCounter, nextBlock, reorg, error_9;
                            return __generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0:
                                        headHash = this._heads[name] || this._genesis;
                                        if (!headHash) {
                                            return [2 /*return*/, 0];
                                        }
                                        if (maxBlocks && maxBlocks < 0) {
                                            throw 'If maxBlocks is provided, it has to be a non-negative number';
                                        }
                                        return [4 /*yield*/, this.dbManager.hashToNumber(headHash)];
                                    case 1:
                                        headBlockNumber = _a.sent();
                                        nextBlockNumber = headBlockNumber.addn(1);
                                        blocksRanCounter = 0;
                                        _a.label = 2;
                                    case 2:
                                        if (!(maxBlocks !== blocksRanCounter)) return [3 /*break*/, 8];
                                        _a.label = 3;
                                    case 3:
                                        _a.trys.push([3, 6, , 7]);
                                        return [4 /*yield*/, this._getBlock(nextBlockNumber)];
                                    case 4:
                                        nextBlock = _a.sent();
                                        this._heads[name] = nextBlock.hash();
                                        reorg = lastBlock ? lastBlock.hash().equals(nextBlock.header.parentHash) : false;
                                        lastBlock = nextBlock;
                                        return [4 /*yield*/, onBlock(nextBlock, reorg)];
                                    case 5:
                                        _a.sent();
                                        nextBlockNumber.iaddn(1);
                                        blocksRanCounter++;
                                        return [3 /*break*/, 7];
                                    case 6:
                                        error_9 = _a.sent();
                                        if (error_9.type === 'NotFoundError') {
                                            return [3 /*break*/, 8];
                                        }
                                        else {
                                            throw error_9;
                                        }
                                        return [3 /*break*/, 7];
                                    case 7: return [3 /*break*/, 2];
                                    case 8: return [4 /*yield*/, this._saveHeads()];
                                    case 9:
                                        _a.sent();
                                        return [2 /*return*/, blocksRanCounter];
                                }
                            });
                        }); })];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    /**
     * Set header hash of a certain `tag`.
     * When calling the iterator, the iterator will start running the first child block after the header hash currenntly stored.
     * @param tag - The tag to save the headHash to
     * @param headHash - The head hash to save
     */
    Blockchain.prototype.setIteratorHead = function (tag, headHash) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.setHead(tag, headHash)];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    /**
     * Set header hash of a certain `tag`.
     * When calling the iterator, the iterator will start running the first child block after the header hash currenntly stored.
     * @param tag - The tag to save the headHash to
     * @param headHash - The head hash to save
     *
     * @deprecated use {@link Blockchain.setIteratorHead()} instead
     */
    Blockchain.prototype.setHead = function (tag, headHash) {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.initAndLock(function () { return __awaiter(_this, void 0, void 0, function () {
                            return __generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0:
                                        this._heads[tag] = headHash;
                                        return [4 /*yield*/, this._saveHeads()];
                                    case 1:
                                        _a.sent();
                                        return [2 /*return*/];
                                }
                            });
                        }); })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    /* Methods regarding re-org operations */
    /**
     * Pushes DB operations to delete canonical number assignments for specified
     * block number and above This only deletes `NumberToHash` references, and not
     * the blocks themselves. Note: this does not write to the DB but only pushes
     * to a DB operations list.
     * @param blockNumber - the block number from which we start deleting
     * canonical chain assignments (including this block)
     * @param headHash - the hash of the current canonical chain head. The _heads
     * reference matching any hash of any of the deleted blocks will be set to
     * this
     * @param ops - the DatabaseOperation list to write DatabaseOperations to
     * @hidden
     */
    Blockchain.prototype._deleteCanonicalChainReferences = function (blockNumber, headHash, ops) {
        var _a;
        return __awaiter(this, void 0, void 0, function () {
            var hash;
            var _this = this;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        blockNumber = blockNumber.clone();
                        return [4 /*yield*/, this.safeNumberToHash(blockNumber)];
                    case 1:
                        hash = _b.sent();
                        _b.label = 2;
                    case 2:
                        if (!hash) return [3 /*break*/, 4];
                        ops.push(helpers_1.DBOp.del(operation_1.DBTarget.NumberToHash, { blockNumber: blockNumber }));
                        // reset stale iterator heads to current canonical head this can, for
                        // instance, make the VM run "older" (i.e. lower number blocks than last
                        // executed block) blocks to verify the chain up to the current, actual,
                        // head.
                        Object.keys(this._heads).forEach(function (name) {
                            if (_this._heads[name].equals(hash)) {
                                // explicitly cast as Buffer: it is not possible that `hash` is false
                                // here, but TypeScript does not understand this.
                                _this._heads[name] = headHash;
                            }
                        });
                        // reset stale headBlock to current canonical
                        if ((_a = this._headBlockHash) === null || _a === void 0 ? void 0 : _a.equals(hash)) {
                            this._headBlockHash = headHash;
                        }
                        blockNumber.iaddn(1);
                        return [4 /*yield*/, this.safeNumberToHash(blockNumber)];
                    case 3:
                        hash = _b.sent();
                        return [3 /*break*/, 2];
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Given a `header`, put all operations to change the canonical chain directly
     * into `ops`. This walks the supplied `header` backwards. It is thus assumed
     * that this header should be canonical header. For each header the
     * corresponding hash corresponding to the current canonical chain in the DB
     * is checked If the number => hash reference does not correspond to the
     * reference in the DB, we overwrite this reference with the implied number =>
     * hash reference Also, each `_heads` member is checked; if these point to a
     * stale hash, then the hash which we terminate the loop (i.e. the first hash
     * which matches the number => hash of the implied chain) is put as this stale
     * head hash The same happens to _headBlockHash
     * @param header - The canonical header.
     * @param ops - The database operations list.
     * @hidden
     */
    Blockchain.prototype._rebuildCanonical = function (header, ops) {
        var _a;
        return __awaiter(this, void 0, void 0, function () {
            var currentNumber, currentCanonicalHash, staleHash, staleHeads, staleHeadBlock, loopCondition, blockHash, blockNumber, error_10;
            var _this = this;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        currentNumber = header.number.clone() // we change this during this method with `isubn`
                        ;
                        currentCanonicalHash = header.hash();
                        staleHash = false;
                        staleHeads = [];
                        staleHeadBlock = false;
                        loopCondition = function () { return __awaiter(_this, void 0, void 0, function () {
                            return __generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, this.safeNumberToHash(currentNumber)];
                                    case 1:
                                        staleHash = _a.sent();
                                        currentCanonicalHash = header.hash();
                                        return [2 /*return*/, !staleHash || !currentCanonicalHash.equals(staleHash)];
                                }
                            });
                        }); };
                        _b.label = 1;
                    case 1: return [4 /*yield*/, loopCondition()];
                    case 2:
                        if (!_b.sent()) return [3 /*break*/, 7];
                        blockHash = header.hash();
                        blockNumber = header.number;
                        helpers_1.DBSaveLookups(blockHash, blockNumber).map(function (op) {
                            ops.push(op);
                        });
                        if (blockNumber.isZero()) {
                            return [3 /*break*/, 7];
                        }
                        // mark each key `_heads` which is currently set to the hash in the DB as
                        // stale to overwrite this later.
                        Object.keys(this._heads).forEach(function (name) {
                            if (staleHash && _this._heads[name].equals(staleHash)) {
                                staleHeads.push(name);
                            }
                        });
                        // flag stale headBlock for reset
                        if (staleHash && ((_a = this._headBlockHash) === null || _a === void 0 ? void 0 : _a.equals(staleHash))) {
                            staleHeadBlock = true;
                        }
                        currentNumber.isubn(1);
                        _b.label = 3;
                    case 3:
                        _b.trys.push([3, 5, , 6]);
                        return [4 /*yield*/, this._getHeader(header.parentHash, currentNumber)];
                    case 4:
                        header = _b.sent();
                        return [3 /*break*/, 6];
                    case 5:
                        error_10 = _b.sent();
                        staleHeads = [];
                        if (error_10.type !== 'NotFoundError') {
                            throw error_10;
                        }
                        return [3 /*break*/, 7];
                    case 6: return [3 /*break*/, 1];
                    case 7:
                        // the stale hash is equal to the blockHash set stale heads to last
                        // previously valid canonical block
                        staleHeads.forEach(function (name) {
                            _this._heads[name] = currentCanonicalHash;
                        });
                        // set stale headBlock to last previously valid canonical block
                        if (staleHeadBlock) {
                            this._headBlockHash = currentCanonicalHash;
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    /* Helper functions */
    /**
     * Builds the `DatabaseOperation[]` list which describes the DB operations to
     * write the heads, head header hash and the head header block to the DB
     * @hidden
     */
    Blockchain.prototype._saveHeadOps = function () {
        return [
            helpers_1.DBOp.set(operation_1.DBTarget.Heads, this._heads),
            helpers_1.DBOp.set(operation_1.DBTarget.HeadHeader, this._headHeaderHash),
            helpers_1.DBOp.set(operation_1.DBTarget.HeadBlock, this._headBlockHash),
        ];
    };
    /**
     * Gets the `DatabaseOperation[]` list to save `_heads`, `_headHeaderHash` and
     * `_headBlockHash` and writes these to the DB
     * @hidden
     */
    Blockchain.prototype._saveHeads = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this.dbManager.batch(this._saveHeadOps())];
            });
        });
    };
    /**
     * Gets a header by hash and number. Header can exist outside the canonical
     * chain
     *
     * @hidden
     */
    Blockchain.prototype._getHeader = function (hash, number) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!!number) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.dbManager.hashToNumber(hash)];
                    case 1:
                        number = _a.sent();
                        _a.label = 2;
                    case 2: return [2 /*return*/, this.dbManager.getHeader(hash, number)];
                }
            });
        });
    };
    /**
     * Gets a header by number. Header must be in the canonical chain
     *
     * @hidden
     */
    Blockchain.prototype._getCanonicalHeader = function (number) {
        return __awaiter(this, void 0, void 0, function () {
            var hash;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.dbManager.numberToHash(number)];
                    case 1:
                        hash = _a.sent();
                        return [2 /*return*/, this._getHeader(hash, number)];
                }
            });
        });
    };
    /**
     * This method either returns a Buffer if there exists one in the DB or if it
     * does not exist (DB throws a `NotFoundError`) then return false If DB throws
     * any other error, this function throws.
     * @param number
     */
    Blockchain.prototype.safeNumberToHash = function (number) {
        return __awaiter(this, void 0, void 0, function () {
            var hash, error_11;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        return [4 /*yield*/, this.dbManager.numberToHash(number)];
                    case 1:
                        hash = _a.sent();
                        return [2 /*return*/, hash];
                    case 2:
                        error_11 = _a.sent();
                        if (error_11.type !== 'NotFoundError') {
                            throw error_11;
                        }
                        return [2 /*return*/, false];
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    return Blockchain;
}());
exports.default = Blockchain;
//# sourceMappingURL=index.js.map