import assert from 'assert'
import BN from 'bn.js'
import * as rlp from 'rlp'
import {
  privateKeyVerify,
  publicKeyCreate,
  publicKeyVerify,
  publicKeyConvert,
} from 'ethereum-cryptography/secp256k1'
import { stripHexPrefix } from 'ethjs-util'
import { KECCAK256_RLP, KECCAK256_NULL } from './constants'
import { zeros, bufferToHex, toBuffer, bufferToInt } from './bytes'
import { keccak, keccak256, keccakFromString, rlphash } from './hash'
import { assertIsString, assertIsHexString, assertIsBuffer } from './helpers'
import { BNLike, BufferLike, bnToUnpaddedBuffer, toType, TypeOutput } from './types'

export interface Key {
  address: Buffer
  weight: number
}

export enum PermissionType {
  Owner = 0,
  Witness = 1,
  Active = 2,
}

export interface Permission {
  type: PermissionType
  id: number
  permissionName: string
  threshold: number
  parentId: number
  operations: BufferLike
  keys: Key[]
}

function keysToRlp(keys: Key[]) {
  return keys.map((ele) => [ele.address, ele.weight])
}

function permissionToRlp(permission: Permission) {
  return [
    permission.type,
    permission.id,
    permission.permissionName,
    permission.threshold,
    permission.parentId,
    permission.operations,
    keysToRlp(permission.keys),
  ]
}

function keysFromRlp(arr: any[]): Key[] {
  return arr.map((ele: any[]) => {
    return {
      address: ele[0],
      weight: bufferToInt(ele[1]),
    }
  })
}

function permissionFromRlp(arr: any[]): Permission {
  return {
    type: bufferToInt(arr[0]),
    id: bufferToInt(arr[1]),
    permissionName: arr[2].toString(),
    threshold: bufferToInt(arr[3]),
    parentId: bufferToInt(arr[4]),
    operations: arr[5],
    keys: keysFromRlp(arr[6]),
  }
}

export interface AccountData {
  nonce?: BNLike
  balance?: BNLike
  stateRoot?: BufferLike
  codeHash?: BufferLike
  asset?: {
    [key: number]: BNLike
  }

  activePermissions?: Permission[]
}

export class Account {
  nonce: BN
  balance: BN
  stateRoot: Buffer
  codeHash: Buffer
  asset: {
    [key: number]: BN
  }
  activePermissions?: Permission[]

  static fromAccountData(accountData: AccountData) {
    const { nonce, balance, stateRoot, codeHash, asset, activePermissions } = accountData

    return new Account(
      nonce ? new BN(toBuffer(nonce)) : undefined,
      balance ? new BN(toBuffer(balance)) : undefined,
      stateRoot ? toBuffer(stateRoot) : undefined,
      codeHash ? toBuffer(codeHash) : undefined,
      asset ? asset : {},
      activePermissions ? activePermissions : []
    )
  }

  public static fromRlpSerializedAccount(serialized: Buffer) {
    const values = rlp.decode(serialized)

    if (!Array.isArray(values)) {
      throw new Error('Invalid serialized account input. Must be array')
    }

    return this.fromValuesArray(values)
  }

  public static fromValuesArray(values: any[]) {
    const [nonce, balance, stateRoot, codeHash, assetArr, activePermissionArr] = values

    const asset: {
      [key: number]: BN
    } = {}

    for (let i = 0; i < assetArr.length; i++) {
      const tokenId = assetArr[i]
      const tokenValue = assetArr[++i]
      asset[new BN(tokenId).toNumber()] = new BN(tokenValue)
    }

    const activePermissions: Permission[] = []
    for (let i = 0; i < activePermissionArr.length; ++i) {
      const perm = activePermissionArr[i]
      activePermissions.push(permissionFromRlp(perm))
    }

    return new Account(
      new BN(nonce),
      new BN(balance),
      stateRoot,
      codeHash,
      asset,
      activePermissions
    )
  }

  /**
   * This constructor assigns and validates the values.
   * Use the static factory methods to assist in creating an Account from varying data types.
   */
  constructor(
    nonce = new BN(0),
    balance = new BN(0),
    stateRoot = KECCAK256_RLP,
    codeHash = KECCAK256_NULL,
    asset = {},
    activePermissions: Permission[] = []
  ) {
    this.nonce = nonce
    this.balance = balance
    this.stateRoot = stateRoot
    this.codeHash = codeHash
    this.asset = asset
    this.activePermissions = activePermissions

    this._validate()
  }

  private _validate() {
    if (this.nonce.lt(new BN(0))) {
      throw new Error('nonce must be greater than zero')
    }
    if (this.balance.lt(new BN(0))) {
      throw new Error('balance must be greater than zero')
    }
    if (this.stateRoot.length !== 32) {
      throw new Error('stateRoot must have a length of 32')
    }
    if (this.codeHash.length !== 32) {
      throw new Error('codeHash must have a length of 32')
    }
  }

  /**
   * Returns a Buffer Array of the raw Buffers for the account, in order.
   */
  raw(): Buffer[] {
    const tokenIds = Object.keys(this.asset)
    const asset: any = []
    tokenIds.forEach((_) => {
      asset.push(bnToUnpaddedBuffer(new BN(Number(_))), bnToUnpaddedBuffer(this.asset[Number(_)]))
    })
    const activePermissionsRlp = (this.activePermissions ?? []).map((ele) => permissionToRlp(ele))
    return [
      bnToUnpaddedBuffer(this.nonce),
      bnToUnpaddedBuffer(this.balance),
      this.stateRoot,
      this.codeHash,
      asset,
      activePermissionsRlp,
    ]
  }

  /**
   * Returns the RLP serialization of the account as a `Buffer`.
   */
  serialize(): Buffer {
    return rlp.encode(this.raw())
  }

  /**
   * Returns a `Boolean` determining if the account is a contract.
   */
  isContract(): boolean {
    return !this.codeHash.equals(KECCAK256_NULL)
  }

  /**
   * Returns a `Boolean` determining if the account is empty complying to the definition of
   * account emptiness in [EIP-161](https://eips.ethereum.org/EIPS/eip-161):
   * "An account is considered empty when it has no code and zero nonce and zero balance."
   */
  isEmpty(): boolean {
    return (
      this.balance.isZero() &&
      this.isEmptyAsset() &&
      this.nonce.isZero() &&
      this.codeHash.equals(KECCAK256_NULL)
    )
  }

  isEmptyAsset(): boolean {
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
    if (!this.asset) {
      return true
    }
    // eslint-disable-next-line no-restricted-syntax
    for (const property in this.asset) {
      const value = this.asset[property]
      if (value.toNumber() != 0) {
        return false
      }
    }
    return true
  }

  updatePermissions({ activePermissions }: { activePermissions: Permission[] }): void {
    this.activePermissions = activePermissions
  }

  getPermissionById(id: number): Permission | undefined {
    if (!this.activePermissions) {
      return undefined
    }
    return this.activePermissions.find((ele) => ele.id == id)
  }

  static getDefaultPermission(owner: Buffer): Permission {
    return this.createDefaultOwnerPermission(owner)
  }

  static createDefaultOwnerPermission(address: Buffer): Permission {
    const key: Key = {
      address,
      weight: 1,
    }

    const ownerPermission: Permission = {
      id: 0,
      keys: [key],
      operations: Buffer.alloc(0),
      parentId: 0,
      permissionName: 'owner',
      threshold: 1,
      type: PermissionType.Owner,
    }

    return ownerPermission
  }
}

/**
 * Checks if the address is a valid. Accepts checksummed addresses too.
 */
export const isValidAddress = function (hexAddress: string): boolean {
  try {
    assertIsString(hexAddress)
  } catch (e) {
    return false
  }

  return /^0x[0-9a-fA-F]{40}$/.test(hexAddress)
}

/**
 * Returns a checksummed address.
 *
 * If a eip1191ChainId is provided, the chainId will be included in the checksum calculation. This
 * has the effect of checksummed addresses for one chain having invalid checksums for others.
 * For more details see [EIP-1191](https://eips.ethereum.org/EIPS/eip-1191).
 *
 * WARNING: Checksums with and without the chainId will differ. As of 2019-06-26, the most commonly
 * used variation in Ethereum was without the chainId. This may change in the future.
 */
export const toChecksumAddress = function (hexAddress: string, eip1191ChainId?: BNLike): string {
  assertIsHexString(hexAddress)
  const address = stripHexPrefix(hexAddress).toLowerCase()

  let prefix = ''
  if (eip1191ChainId) {
    const chainId = toType(eip1191ChainId, TypeOutput.BN)
    prefix = chainId.toString() + '0x'
  }

  const hash = keccakFromString(prefix + address).toString('hex')
  let ret = '0x'

  for (let i = 0; i < address.length; i++) {
    if (parseInt(hash[i], 16) >= 8) {
      ret += address[i].toUpperCase()
    } else {
      ret += address[i]
    }
  }

  return ret
}

/**
 * Checks if the address is a valid checksummed address.
 *
 * See toChecksumAddress' documentation for details about the eip1191ChainId parameter.
 */
export const isValidChecksumAddress = function (
  hexAddress: string,
  eip1191ChainId?: BNLike
): boolean {
  return isValidAddress(hexAddress) && toChecksumAddress(hexAddress, eip1191ChainId) === hexAddress
}

/**
 * Generates an address of a newly created contract.
 * @param from The address which is creating this new address
 * @param nonce The nonce of the from account
 */
export const generateAddress = function (from: Buffer, nonce: Buffer): Buffer {
  assertIsBuffer(from)
  assertIsBuffer(nonce)
  const nonceBN = new BN(nonce)

  if (nonceBN.isZero()) {
    // in RLP we want to encode null in the case of zero nonce
    // read the RLP documentation for an answer if you dare
    return rlphash([from, null]).slice(-20)
  }

  // Only take the lower 160bits of the hash
  return rlphash([from, Buffer.from(nonceBN.toArray())]).slice(-20)
}

/**
 * Generates an address for a contract created using CREATE2.
 * @param from The address which is creating this new address
 * @param salt A salt
 * @param initCode The init code of the contract being created
 */
export const generateAddress2 = function (from: Buffer, salt: Buffer, initCode: Buffer): Buffer {
  assertIsBuffer(from)
  assertIsBuffer(salt)
  assertIsBuffer(initCode)

  assert(from.length === 20)
  assert(salt.length === 32)

  const address = keccak256(
    Buffer.concat([Buffer.from('41', 'hex'), from, salt, keccak256(initCode)])
  )

  return address.slice(-20)
}

/**
 * Checks if the private key satisfies the rules of the curve secp256k1.
 */
export const isValidPrivate = function (privateKey: Buffer): boolean {
  return privateKeyVerify(privateKey)
}

/**
 * Checks if the public key satisfies the rules of the curve secp256k1
 * and the requirements of Ethereum.
 * @param publicKey The two points of an uncompressed key, unless sanitize is enabled
 * @param sanitize Accept public keys in other formats
 */
export const isValidPublic = function (publicKey: Buffer, sanitize: boolean = false): boolean {
  assertIsBuffer(publicKey)
  if (publicKey.length === 64) {
    // Convert to SEC1 for secp256k1
    return publicKeyVerify(Buffer.concat([Buffer.from([4]), publicKey]))
  }

  if (!sanitize) {
    return false
  }

  return publicKeyVerify(publicKey)
}

/**
 * Returns the ethereum address of a given public key.
 * Accepts "Ethereum public keys" and SEC1 encoded keys.
 * @param pubKey The two points of an uncompressed key, unless sanitize is enabled
 * @param sanitize Accept public keys in other formats
 */
export const pubToAddress = function (pubKey: Buffer, sanitize: boolean = false): Buffer {
  assertIsBuffer(pubKey)
  if (sanitize && pubKey.length !== 64) {
    pubKey = Buffer.from(publicKeyConvert(pubKey, false).slice(1))
  }
  assert(pubKey.length === 64)
  // Only take the lower 160bits of the hash
  return keccak(pubKey).slice(-20)
}
export const publicToAddress = pubToAddress

/**
 * Returns the ethereum public key of a given private key.
 * @param privateKey A private key must be 256 bits wide
 */
export const privateToPublic = function (privateKey: Buffer): Buffer {
  assertIsBuffer(privateKey)
  // skip the type flag and use the X, Y points
  return Buffer.from(publicKeyCreate(privateKey, false)).slice(1)
}

/**
 * Returns the ethereum address of a given private key.
 * @param privateKey A private key must be 256 bits wide
 */
export const privateToAddress = function (privateKey: Buffer): Buffer {
  return publicToAddress(privateToPublic(privateKey))
}

/**
 * Converts a public key to the Ethereum format.
 */
export const importPublic = function (publicKey: Buffer): Buffer {
  assertIsBuffer(publicKey)
  if (publicKey.length !== 64) {
    publicKey = Buffer.from(publicKeyConvert(publicKey, false).slice(1))
  }
  return publicKey
}

/**
 * Returns the zero address.
 */
export const zeroAddress = function (): string {
  const addressLength = 20
  const addr = zeros(addressLength)
  return bufferToHex(addr)
}

/**
 * Checks if a given address is the zero address.
 */
export const isZeroAddress = function (hexAddress: string): boolean {
  try {
    assertIsString(hexAddress)
  } catch (e) {
    return false
  }

  const zeroAddr = zeroAddress()
  return zeroAddr === hexAddress
}
