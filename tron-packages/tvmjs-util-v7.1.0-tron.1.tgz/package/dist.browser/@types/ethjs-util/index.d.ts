/// <reference types="node" />
declare module 'ethjs-util' {
    /**
     * @description Returns a `Boolean` on whether or not the a `String` starts with '0x'
     */
    function isHexPrefixed(str: string): boolean;
    /**
     * @description Removes '0x' from a given `String` if present
     */
    function stripHexPrefix(str: string): string;
    /**
     * @description Pads a `String` to have an even length
     */
    function padToEven(value: string): string;
    /**
     * @description Converts a `Number` into a hex `String`
     */
    function intToHex(i: number): string;
    /**
     * @description Converts an `Number` to a `Buffer`
     */
    function intToBuffer(i: number): Buffer;
    /**
     * @description Get the binary size of a string
     */
    function getBinarySize(str: string): number;
    /**
     * @description Returns TRUE if the first specified array contains all elements
     *              from the second one. FALSE otherwise. If `some` is true, will
     *              return true if first specified array contain some elements of
     *              the second.
     */
    function arrayContainsArray(superset: any[], subset: any[], some?: boolean): boolean;
    /**
     * @description Should be called to get utf8 from it's hex representation
     */
    function toUtf8(hex: string): string;
    /**
     * @description Should be called to get ascii from it's hex representation
     */
    function toAscii(hex: string): string;
    /**
     * @description Should be called to get hex representation (prefixed by 0x) of utf8 string
     */
    function fromUtf8(stringValue: string): string;
    /**
     * @description Should be called to get hex representation (prefixed by 0x) of ascii string
     */
    function fromAscii(stringValue: string): string;
    /**
     * @description getKeys([{a: 1, b: 2}, {a: 3, b: 4}], 'a') => [1, 3]
     */
    function getKeys(params: any[], key: string, allowEmpty?: boolean): any[];
    /**
     * @description check if string is hex string of specific length
     */
    function isHexString(value: string, length?: number): boolean;
}
