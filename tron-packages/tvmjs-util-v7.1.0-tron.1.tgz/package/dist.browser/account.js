"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.isZeroAddress = exports.zeroAddress = exports.importPublic = exports.privateToAddress = exports.privateToPublic = exports.publicToAddress = exports.pubToAddress = exports.isValidPublic = exports.isValidPrivate = exports.generateAddress2 = exports.generateAddress = exports.isValidChecksumAddress = exports.toChecksumAddress = exports.isValidAddress = exports.Account = exports.PermissionType = void 0;
var assert_1 = __importDefault(require("assert"));
var bn_js_1 = __importDefault(require("bn.js"));
var rlp = __importStar(require("rlp"));
var secp256k1_1 = require("ethereum-cryptography/secp256k1");
var ethjs_util_1 = require("ethjs-util");
var constants_1 = require("./constants");
var bytes_1 = require("./bytes");
var hash_1 = require("./hash");
var helpers_1 = require("./helpers");
var types_1 = require("./types");
var PermissionType;
(function (PermissionType) {
    PermissionType[PermissionType["Owner"] = 0] = "Owner";
    PermissionType[PermissionType["Witness"] = 1] = "Witness";
    PermissionType[PermissionType["Active"] = 2] = "Active";
})(PermissionType = exports.PermissionType || (exports.PermissionType = {}));
function keysToRlp(keys) {
    return keys.map(function (ele) { return [ele.address, ele.weight]; });
}
function permissionToRlp(permission) {
    return [
        permission.type,
        permission.id,
        permission.permissionName,
        permission.threshold,
        permission.parentId,
        permission.operations,
        keysToRlp(permission.keys),
    ];
}
function keysFromRlp(arr) {
    return arr.map(function (ele) {
        return {
            address: ele[0],
            weight: bytes_1.bufferToInt(ele[1]),
        };
    });
}
function permissionFromRlp(arr) {
    return {
        type: bytes_1.bufferToInt(arr[0]),
        id: bytes_1.bufferToInt(arr[1]),
        permissionName: arr[2].toString(),
        threshold: bytes_1.bufferToInt(arr[3]),
        parentId: bytes_1.bufferToInt(arr[4]),
        operations: arr[5],
        keys: keysFromRlp(arr[6]),
    };
}
var Account = /** @class */ (function () {
    /**
     * This constructor assigns and validates the values.
     * Use the static factory methods to assist in creating an Account from varying data types.
     */
    function Account(nonce, balance, stateRoot, codeHash, asset, activePermissions) {
        if (nonce === void 0) { nonce = new bn_js_1.default(0); }
        if (balance === void 0) { balance = new bn_js_1.default(0); }
        if (stateRoot === void 0) { stateRoot = constants_1.KECCAK256_RLP; }
        if (codeHash === void 0) { codeHash = constants_1.KECCAK256_NULL; }
        if (asset === void 0) { asset = {}; }
        if (activePermissions === void 0) { activePermissions = []; }
        this.nonce = nonce;
        this.balance = balance;
        this.stateRoot = stateRoot;
        this.codeHash = codeHash;
        this.asset = asset;
        this.activePermissions = activePermissions;
        this._validate();
    }
    Account.fromAccountData = function (accountData) {
        var nonce = accountData.nonce, balance = accountData.balance, stateRoot = accountData.stateRoot, codeHash = accountData.codeHash, asset = accountData.asset, activePermissions = accountData.activePermissions;
        return new Account(nonce ? new bn_js_1.default(bytes_1.toBuffer(nonce)) : undefined, balance ? new bn_js_1.default(bytes_1.toBuffer(balance)) : undefined, stateRoot ? bytes_1.toBuffer(stateRoot) : undefined, codeHash ? bytes_1.toBuffer(codeHash) : undefined, asset ? asset : {}, activePermissions ? activePermissions : []);
    };
    Account.fromRlpSerializedAccount = function (serialized) {
        var values = rlp.decode(serialized);
        if (!Array.isArray(values)) {
            throw new Error('Invalid serialized account input. Must be array');
        }
        return this.fromValuesArray(values);
    };
    Account.fromValuesArray = function (values) {
        var _a = __read(values, 6), nonce = _a[0], balance = _a[1], stateRoot = _a[2], codeHash = _a[3], assetArr = _a[4], activePermissionArr = _a[5];
        var asset = {};
        for (var i = 0; i < assetArr.length; i++) {
            var tokenId = assetArr[i];
            var tokenValue = assetArr[++i];
            asset[new bn_js_1.default(tokenId).toNumber()] = new bn_js_1.default(tokenValue);
        }
        var activePermissions = [];
        for (var i = 0; i < activePermissionArr.length; ++i) {
            var perm = activePermissionArr[i];
            activePermissions.push(permissionFromRlp(perm));
        }
        return new Account(new bn_js_1.default(nonce), new bn_js_1.default(balance), stateRoot, codeHash, asset, activePermissions);
    };
    Account.prototype._validate = function () {
        if (this.nonce.lt(new bn_js_1.default(0))) {
            throw new Error('nonce must be greater than zero');
        }
        if (this.balance.lt(new bn_js_1.default(0))) {
            throw new Error('balance must be greater than zero');
        }
        if (this.stateRoot.length !== 32) {
            throw new Error('stateRoot must have a length of 32');
        }
        if (this.codeHash.length !== 32) {
            throw new Error('codeHash must have a length of 32');
        }
    };
    /**
     * Returns a Buffer Array of the raw Buffers for the account, in order.
     */
    Account.prototype.raw = function () {
        var _this = this;
        var _a;
        var tokenIds = Object.keys(this.asset);
        var asset = [];
        tokenIds.forEach(function (_) {
            asset.push(types_1.bnToUnpaddedBuffer(new bn_js_1.default(Number(_))), types_1.bnToUnpaddedBuffer(_this.asset[Number(_)]));
        });
        var activePermissionsRlp = ((_a = this.activePermissions) !== null && _a !== void 0 ? _a : []).map(function (ele) { return permissionToRlp(ele); });
        return [
            types_1.bnToUnpaddedBuffer(this.nonce),
            types_1.bnToUnpaddedBuffer(this.balance),
            this.stateRoot,
            this.codeHash,
            asset,
            activePermissionsRlp,
        ];
    };
    /**
     * Returns the RLP serialization of the account as a `Buffer`.
     */
    Account.prototype.serialize = function () {
        return rlp.encode(this.raw());
    };
    /**
     * Returns a `Boolean` determining if the account is a contract.
     */
    Account.prototype.isContract = function () {
        return !this.codeHash.equals(constants_1.KECCAK256_NULL);
    };
    /**
     * Returns a `Boolean` determining if the account is empty complying to the definition of
     * account emptiness in [EIP-161](https://eips.ethereum.org/EIPS/eip-161):
     * "An account is considered empty when it has no code and zero nonce and zero balance."
     */
    Account.prototype.isEmpty = function () {
        return (this.balance.isZero() &&
            this.isEmptyAsset() &&
            this.nonce.isZero() &&
            this.codeHash.equals(constants_1.KECCAK256_NULL));
    };
    Account.prototype.isEmptyAsset = function () {
        // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
        if (!this.asset) {
            return true;
        }
        // eslint-disable-next-line no-restricted-syntax
        for (var property in this.asset) {
            var value = this.asset[property];
            if (value.toNumber() != 0) {
                return false;
            }
        }
        return true;
    };
    Account.prototype.updatePermissions = function (_a) {
        var activePermissions = _a.activePermissions;
        this.activePermissions = activePermissions;
    };
    Account.prototype.getPermissionById = function (id) {
        if (!this.activePermissions) {
            return undefined;
        }
        return this.activePermissions.find(function (ele) { return ele.id == id; });
    };
    Account.getDefaultPermission = function (owner) {
        return this.createDefaultOwnerPermission(owner);
    };
    Account.createDefaultOwnerPermission = function (address) {
        var key = {
            address: address,
            weight: 1,
        };
        var ownerPermission = {
            id: 0,
            keys: [key],
            operations: Buffer.alloc(0),
            parentId: 0,
            permissionName: 'owner',
            threshold: 1,
            type: PermissionType.Owner,
        };
        return ownerPermission;
    };
    return Account;
}());
exports.Account = Account;
/**
 * Checks if the address is a valid. Accepts checksummed addresses too.
 */
exports.isValidAddress = function (hexAddress) {
    try {
        helpers_1.assertIsString(hexAddress);
    }
    catch (e) {
        return false;
    }
    return /^0x[0-9a-fA-F]{40}$/.test(hexAddress);
};
/**
 * Returns a checksummed address.
 *
 * If a eip1191ChainId is provided, the chainId will be included in the checksum calculation. This
 * has the effect of checksummed addresses for one chain having invalid checksums for others.
 * For more details see [EIP-1191](https://eips.ethereum.org/EIPS/eip-1191).
 *
 * WARNING: Checksums with and without the chainId will differ. As of 2019-06-26, the most commonly
 * used variation in Ethereum was without the chainId. This may change in the future.
 */
exports.toChecksumAddress = function (hexAddress, eip1191ChainId) {
    helpers_1.assertIsHexString(hexAddress);
    var address = ethjs_util_1.stripHexPrefix(hexAddress).toLowerCase();
    var prefix = '';
    if (eip1191ChainId) {
        var chainId = types_1.toType(eip1191ChainId, types_1.TypeOutput.BN);
        prefix = chainId.toString() + '0x';
    }
    var hash = hash_1.keccakFromString(prefix + address).toString('hex');
    var ret = '0x';
    for (var i = 0; i < address.length; i++) {
        if (parseInt(hash[i], 16) >= 8) {
            ret += address[i].toUpperCase();
        }
        else {
            ret += address[i];
        }
    }
    return ret;
};
/**
 * Checks if the address is a valid checksummed address.
 *
 * See toChecksumAddress' documentation for details about the eip1191ChainId parameter.
 */
exports.isValidChecksumAddress = function (hexAddress, eip1191ChainId) {
    return exports.isValidAddress(hexAddress) && exports.toChecksumAddress(hexAddress, eip1191ChainId) === hexAddress;
};
/**
 * Generates an address of a newly created contract.
 * @param from The address which is creating this new address
 * @param nonce The nonce of the from account
 */
exports.generateAddress = function (from, nonce) {
    helpers_1.assertIsBuffer(from);
    helpers_1.assertIsBuffer(nonce);
    var nonceBN = new bn_js_1.default(nonce);
    if (nonceBN.isZero()) {
        // in RLP we want to encode null in the case of zero nonce
        // read the RLP documentation for an answer if you dare
        return hash_1.rlphash([from, null]).slice(-20);
    }
    // Only take the lower 160bits of the hash
    return hash_1.rlphash([from, Buffer.from(nonceBN.toArray())]).slice(-20);
};
/**
 * Generates an address for a contract created using CREATE2.
 * @param from The address which is creating this new address
 * @param salt A salt
 * @param initCode The init code of the contract being created
 */
exports.generateAddress2 = function (from, salt, initCode) {
    helpers_1.assertIsBuffer(from);
    helpers_1.assertIsBuffer(salt);
    helpers_1.assertIsBuffer(initCode);
    assert_1.default(from.length === 20);
    assert_1.default(salt.length === 32);
    var address = hash_1.keccak256(Buffer.concat([Buffer.from('41', 'hex'), from, salt, hash_1.keccak256(initCode)]));
    return address.slice(-20);
};
/**
 * Checks if the private key satisfies the rules of the curve secp256k1.
 */
exports.isValidPrivate = function (privateKey) {
    return secp256k1_1.privateKeyVerify(privateKey);
};
/**
 * Checks if the public key satisfies the rules of the curve secp256k1
 * and the requirements of Ethereum.
 * @param publicKey The two points of an uncompressed key, unless sanitize is enabled
 * @param sanitize Accept public keys in other formats
 */
exports.isValidPublic = function (publicKey, sanitize) {
    if (sanitize === void 0) { sanitize = false; }
    helpers_1.assertIsBuffer(publicKey);
    if (publicKey.length === 64) {
        // Convert to SEC1 for secp256k1
        return secp256k1_1.publicKeyVerify(Buffer.concat([Buffer.from([4]), publicKey]));
    }
    if (!sanitize) {
        return false;
    }
    return secp256k1_1.publicKeyVerify(publicKey);
};
/**
 * Returns the ethereum address of a given public key.
 * Accepts "Ethereum public keys" and SEC1 encoded keys.
 * @param pubKey The two points of an uncompressed key, unless sanitize is enabled
 * @param sanitize Accept public keys in other formats
 */
exports.pubToAddress = function (pubKey, sanitize) {
    if (sanitize === void 0) { sanitize = false; }
    helpers_1.assertIsBuffer(pubKey);
    if (sanitize && pubKey.length !== 64) {
        pubKey = Buffer.from(secp256k1_1.publicKeyConvert(pubKey, false).slice(1));
    }
    assert_1.default(pubKey.length === 64);
    // Only take the lower 160bits of the hash
    return hash_1.keccak(pubKey).slice(-20);
};
exports.publicToAddress = exports.pubToAddress;
/**
 * Returns the ethereum public key of a given private key.
 * @param privateKey A private key must be 256 bits wide
 */
exports.privateToPublic = function (privateKey) {
    helpers_1.assertIsBuffer(privateKey);
    // skip the type flag and use the X, Y points
    return Buffer.from(secp256k1_1.publicKeyCreate(privateKey, false)).slice(1);
};
/**
 * Returns the ethereum address of a given private key.
 * @param privateKey A private key must be 256 bits wide
 */
exports.privateToAddress = function (privateKey) {
    return exports.publicToAddress(exports.privateToPublic(privateKey));
};
/**
 * Converts a public key to the Ethereum format.
 */
exports.importPublic = function (publicKey) {
    helpers_1.assertIsBuffer(publicKey);
    if (publicKey.length !== 64) {
        publicKey = Buffer.from(secp256k1_1.publicKeyConvert(publicKey, false).slice(1));
    }
    return publicKey;
};
/**
 * Returns the zero address.
 */
exports.zeroAddress = function () {
    var addressLength = 20;
    var addr = bytes_1.zeros(addressLength);
    return bytes_1.bufferToHex(addr);
};
/**
 * Checks if a given address is the zero address.
 */
exports.isZeroAddress = function (hexAddress) {
    try {
        helpers_1.assertIsString(hexAddress);
    }
    catch (e) {
        return false;
    }
    var zeroAddr = exports.zeroAddress();
    return zeroAddr === hexAddress;
};
//# sourceMappingURL=account.js.map