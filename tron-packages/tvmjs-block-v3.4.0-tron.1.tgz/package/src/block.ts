/* eslint-disable no-dupe-class-members */

import { BaseTrie as Trie } from 'merkle-patricia-tree'
import { rlp, KECCAK256_RLP } from '@tvmjs/util'
import Common from '@tvmjs/common'
import {
  TransactionFactory,
  TypedTransaction,
  TxOptions,
  FeeMarketEIP1559Transaction,
  Transaction,
  Capability,
} from '@tvmjs/tx'
import { BlockHeader } from './header'
import { BlockData, BlockOptions, JsonBlock, BlockBuffer, Blockchain } from './types'

/**
 * An object that represents the block.
 */
export class Block {
  public readonly header: BlockHeader
  public readonly transactions: TypedTransaction[] = []
  public readonly txTrie = new Trie()
  public readonly _common: Common

  /**
   * Static constructor to create a block from a block data dictionary
   *
   * @param blockData
   * @param opts
   */
  public static fromBlockData(blockData: BlockData = {}, opts?: BlockOptions) {
    const { header: headerData, transactions: txsData } = blockData

    const header = BlockHeader.fromHeaderData(headerData, opts)

    // parse transactions
    const transactions = []
    for (const txData of txsData ?? []) {
      const tx = TransactionFactory.fromTxData(txData, {
        ...opts,
        // Use header common in case of hardforkByBlockNumber being activated
        common: header._common,
      } as TxOptions)
      transactions.push(tx)
    }

    return new Block(header, transactions, opts)
  }

  /**
   * Static constructor to create a block from a RLP-serialized block
   *
   * @param serialized
   * @param opts
   */
  public static fromRLPSerializedBlock(serialized: Buffer, opts?: BlockOptions) {
    const values = rlp.decode(serialized) as any as BlockBuffer

    if (!Array.isArray(values)) {
      throw new Error('Invalid serialized block input. Must be array')
    }

    return Block.fromValuesArray(values, opts)
  }

  /**
   * Static constructor to create a block from an array of Buffer values
   *
   * @param values
   * @param opts
   */
  public static fromValuesArray(values: BlockBuffer, opts?: BlockOptions) {
    if (values.length > 2) {
      throw new Error('invalid block. More values than expected were received')
    }

    const [headerData, txsData] = values

    const header = BlockHeader.fromValuesArray(headerData, opts)

    // parse transactions
    const transactions = []
    for (const txData of txsData || []) {
      transactions.push(
        TransactionFactory.fromBlockBodyData(txData, {
          ...opts,
          // Use header common in case of hardforkByBlockNumber being activated
          common: header._common,
        })
      )
    }

    return new Block(header, transactions, opts)
  }

  /**
   * Alias for {@link Block.fromBlockData} with {@link BlockOptions.initWithGenesisHeader} set to true.
   */
  public static genesis(blockData: BlockData = {}, opts?: BlockOptions) {
    opts = { ...opts, initWithGenesisHeader: true }
    return Block.fromBlockData(blockData, opts)
  }

  /**
   * This constructor takes the values, validates them, assigns them and freezes the object.
   * Use the static factory methods to assist in creating a Block object from varying data types and options.
   */
  constructor(
    header?: BlockHeader,
    transactions: TypedTransaction[] = [],
    opts: BlockOptions = {}
  ) {
    this.header = header ?? BlockHeader.fromHeaderData({}, opts)
    this.transactions = transactions
    this._common = this.header._common

    const freeze = opts?.freeze ?? true
    if (freeze) {
      Object.freeze(this)
    }
  }

  /**
   * Returns a Buffer Array of the raw Buffers of this block, in order.
   */
  raw(): BlockBuffer {
    return [
      this.header.raw(),
      this.transactions.map((tx) =>
        tx.supports(Capability.EIP2718TypedTransaction) ? tx.serialize() : tx.raw()
      ) as Buffer[],
    ]
  }

  /**
   * Produces a hash the RLP of the block.
   */
  hash(): Buffer {
    return this.header.hash()
  }

  /**
   * Determines if this block is the genesis block.
   */
  isGenesis(): boolean {
    return this.header.isGenesis()
  }

  /**
   * Returns the rlp encoding of the block.
   */
  serialize(): Buffer {
    return rlp.encode(this.raw())
  }

  /**
   * Generates transaction trie for validation.
   */
  async genTxTrie(): Promise<void> {
    const { transactions, txTrie } = this
    for (let i = 0; i < transactions.length; i++) {
      const tx = transactions[i]
      const key = rlp.encode(i)
      const value = tx.serialize()
      await txTrie.put(key, value)
    }
  }

  /**
   * Validates the transaction trie by generating a trie
   * and do a check on the root hash.
   */
  async validateTransactionsTrie(): Promise<boolean> {
    let result
    if (this.transactions.length === 0) {
      result = this.header.transactionsTrie.equals(KECCAK256_RLP)
      return result
    }

    if (this.txTrie.root.equals(KECCAK256_RLP)) {
      await this.genTxTrie()
    }
    result = this.txTrie.root.equals(this.header.transactionsTrie)
    return result
  }

  /**
   * Validates transaction signatures and minimum gas requirements.
   *
   * @param stringError - If `true`, a string with the indices of the invalid txs is returned.
   */
  validateTransactions(): boolean
  validateTransactions(stringError: false): boolean
  validateTransactions(stringError: true): string[]
  validateTransactions(stringError = false) {
    const errors: string[] = []
    this.transactions.forEach((tx, i) => {
      const errs = <string[]>tx.validate(true)
      if (this._common.isActivatedEIP(1559)) {
        if (tx.supports(Capability.EIP1559FeeMarket)) {
          tx = tx as FeeMarketEIP1559Transaction
          if (tx.maxFeePerGas.lt(this.header.baseFeePerGas!)) {
            errs.push('tx unable to pay base fee (EIP-1559 tx)')
          }
        } else {
          tx = tx as Transaction
          if (tx.gasPrice.lt(this.header.baseFeePerGas!)) {
            errs.push('tx unable to pay base fee (non EIP-1559 tx)')
          }
        }
      }
      if (errs.length > 0) {
        errors.push(`errors at tx ${i}: ${errs.join(', ')}`)
      }
    })

    return stringError ? errors : errors.length === 0
  }

  /**
   * Performs the following consistency checks on the block:
   *
   * - Value checks on the header fields
   * - Signature and gasLimit validation for included txs
   * - Validation of the tx trie
   * - Consistency checks and header validation of included uncles
   *
   * Throws if invalid.
   *
   * @param blockchain - validate against an @ethereumjs/blockchain
   * @param onlyHeader - if should only validate the header (skips validating txTrie and unclesHash) (default: false)
   */
  async validate(blockchain: Blockchain, onlyHeader: boolean = false): Promise<void> {
    await this.header.validate(blockchain)
    await this.validateData(onlyHeader)
  }
  /**
   * Validates the block data, throwing if invalid.
   * This can be checked on the Block itself without needing access to any parent block
   * It checks:
   * - All transactions are valid
   * - The transactions trie is valid
   * - The uncle hash is valid
   * @param onlyHeader if only passed the header, skip validating txTrie and unclesHash (default: false)
   */
  async validateData(onlyHeader: boolean = false): Promise<void> {
    const txErrors = this.validateTransactions(true)
    if (txErrors.length > 0) {
      const msg = `invalid transactions: ${txErrors.join(' ')}`
      throw this.header._error(msg)
    }

    if (!onlyHeader) {
      const validateTxTrie = await this.validateTransactionsTrie()
      if (!validateTxTrie) {
        throw new Error('invalid transaction trie')
      }
    }
  }

  /**
   * Validates if the block gasLimit remains in the
   * boundaries set by the protocol.
   *
   * @param parentBlock - the parent of this `Block`
   */
  validateGasLimit(parentBlock: Block): boolean {
    return this.header.validateGasLimit(parentBlock.header)
  }

  /**
   * Returns the block in JSON format.
   */
  toJSON(): JsonBlock {
    return {
      header: this.header.toJSON(),
      transactions: this.transactions.map((tx) => tx.toJSON()),
    }
  }
}
