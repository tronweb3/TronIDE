import Common from '@tvmjs/common'
import {
  Address,
  BN,
  bnToHex,
  bnToUnpaddedBuffer,
  KECCAK256_RLP,
  rlp,
  rlphash,
  toBuffer,
  zeros,
} from '@tvmjs/util'
import { HeaderData, JsonHeader, BlockHeaderBuffer, Blockchain, BlockOptions } from './types'

const DEFAULT_GAS_LIMIT = new BN(Buffer.from('ffffffffffffff', 'hex'))

/**
 * An object that represents the block header.
 */
export class BlockHeader {
  public readonly parentHash: Buffer
  public readonly coinbase: Address
  public readonly stateRoot: Buffer
  public readonly transactionsTrie: Buffer
  public readonly receiptTrie: Buffer
  public readonly bloom: Buffer
  public readonly number: BN
  public readonly gasLimit: BN
  public readonly gasUsed: BN
  public readonly timestamp: BN
  public readonly baseFeePerGas?: BN

  public readonly _common: Common
  public _errorPostfix = ''

  /**
   * Static constructor to create a block header from a header data dictionary
   *
   * @param headerData
   * @param opts
   */
  public static fromHeaderData(headerData: HeaderData = {}, opts: BlockOptions = {}) {
    const {
      parentHash,
      coinbase,
      stateRoot,
      transactionsTrie,
      receiptTrie,
      bloom,
      number,
      gasLimit,
      gasUsed,
      timestamp,
      baseFeePerGas,
    } = headerData

    return new BlockHeader(
      parentHash ? toBuffer(parentHash) : zeros(32),
      coinbase ? new Address(toBuffer(coinbase)) : Address.zero(),
      stateRoot ? toBuffer(stateRoot) : zeros(32),
      transactionsTrie ? toBuffer(transactionsTrie) : KECCAK256_RLP,
      receiptTrie ? toBuffer(receiptTrie) : KECCAK256_RLP,
      bloom ? toBuffer(bloom) : zeros(256),
      number ? new BN(toBuffer(number)) : new BN(0),
      gasLimit ? new BN(toBuffer(gasLimit)) : DEFAULT_GAS_LIMIT,
      gasUsed ? new BN(toBuffer(gasUsed)) : new BN(0),
      timestamp ? new BN(toBuffer(timestamp)) : new BN(0),
      opts,
      baseFeePerGas !== undefined ? new BN(toBuffer(baseFeePerGas)) : undefined
    )
  }

  /**
   * Static constructor to create a block header from a RLP-serialized header
   *
   * @param headerData
   * @param opts
   */
  public static fromRLPSerializedHeader(serialized: Buffer, opts: BlockOptions = {}) {
    const values = rlp.decode(serialized)

    if (!Array.isArray(values)) {
      throw new Error('Invalid serialized header input. Must be array')
    }

    return BlockHeader.fromValuesArray(values, opts)
  }

  /**
   * Static constructor to create a block header from an array of Buffer values
   *
   * @param headerData
   * @param opts
   */
  public static fromValuesArray(values: BlockHeaderBuffer, opts: BlockOptions = {}) {
    const [
      parentHash,
      coinbase,
      stateRoot,
      transactionsTrie,
      receiptTrie,
      bloom,
      number,
      gasLimit,
      gasUsed,
      timestamp,
      baseFeePerGas,
    ] = values

    if (values.length > 11) {
      throw new Error('invalid header. More values than expected were received')
    }
    if (values.length < 10) {
      throw new Error('invalid header. Less values than expected were received')
    }

    return new BlockHeader(
      toBuffer(parentHash),
      new Address(toBuffer(coinbase)),
      toBuffer(stateRoot),
      toBuffer(transactionsTrie),
      toBuffer(receiptTrie),
      toBuffer(bloom),
      new BN(toBuffer(number)),
      new BN(toBuffer(gasLimit)),
      new BN(toBuffer(gasUsed)),
      new BN(toBuffer(timestamp)),
      opts,
      baseFeePerGas !== undefined ? new BN(toBuffer(baseFeePerGas)) : undefined
    )
  }

  /**
   * Alias for {@link BlockHeader.fromHeaderData} with {@link BlockOptions.initWithGenesisHeader} set to true.
   */
  public static genesis(headerData: HeaderData = {}, opts?: BlockOptions) {
    opts = { ...opts, initWithGenesisHeader: true }
    return BlockHeader.fromHeaderData(headerData, opts)
  }

  /**
   * This constructor takes the values, validates them, assigns them and freezes the object.
   *
   * @deprecated - Use the public static factory methods to assist in creating a Header object from
   * varying data types. For a default empty header, use {@link BlockHeader.fromHeaderData}.
   *
   */
  constructor(
    parentHash: Buffer,
    coinbase: Address,
    stateRoot: Buffer,
    transactionsTrie: Buffer,
    receiptTrie: Buffer,
    bloom: Buffer,
    number: BN,
    gasLimit: BN,
    gasUsed: BN,
    timestamp: BN,
    options: BlockOptions = {},
    baseFeePerGas?: BN
  ) {
    if (options.common) {
      this._common = options.common.copy()
    } else {
      const chain = 'mainnet' // default
      if (options.initWithGenesisHeader) {
        this._common = new Common({ chain, hardfork: 'chainstart' })
      } else {
        // This initializes on the Common default hardfork
        this._common = new Common({ chain })
      }
    }

    if (options.hardforkByBlockNumber) {
      this._common.setHardforkByBlockNumber(number.toNumber())
    }

    if (this._common.isActivatedEIP(1559)) {
      if (baseFeePerGas === undefined) {
        baseFeePerGas = new BN(7)
      }
    } else {
      if (baseFeePerGas) {
        throw new Error('A base fee for a block can only be set with EIP1559 being activated')
      }
    }

    if (options.initWithGenesisHeader) {
      number = new BN(0)
      if (gasLimit.eq(DEFAULT_GAS_LIMIT)) {
        gasLimit = new BN(toBuffer(this._common.genesis().gasLimit))
      }
      if (timestamp.isZero()) {
        timestamp = new BN(toBuffer(this._common.genesis().timestamp))
      }
      if (stateRoot.equals(zeros(32))) {
        stateRoot = toBuffer(this._common.genesis().stateRoot)
      }
    }

    this.parentHash = parentHash
    this.coinbase = coinbase
    this.stateRoot = stateRoot
    this.transactionsTrie = transactionsTrie
    this.receiptTrie = receiptTrie
    this.bloom = bloom
    this.number = number
    this.gasLimit = gasLimit
    this.gasUsed = gasUsed
    this.timestamp = timestamp
    this.baseFeePerGas = baseFeePerGas

    this._validateHeaderFields()

    this._errorPostfix = `block number=${this.number.toNumber()} hash=${this.hash().toString(
      'hex'
    )}`

    const freeze = options?.freeze ?? true
    if (freeze) {
      Object.freeze(this)
    }
  }

  /**
   * Validates correct buffer lengths, throws if invalid.
   */
  _validateHeaderFields() {
    const { parentHash, stateRoot, transactionsTrie, receiptTrie } = this

    if (parentHash.length !== 32) {
      throw new Error(`parentHash must be 32 bytes, received ${parentHash.length} bytes`)
    }
    if (stateRoot.length !== 32) {
      throw new Error(`stateRoot must be 32 bytes, received ${stateRoot.length} bytes`)
    }
    if (transactionsTrie.length !== 32) {
      throw new Error(
        `transactionsTrie must be 32 bytes, received ${transactionsTrie.length} bytes`
      )
    }
    if (receiptTrie.length !== 32) {
      throw new Error(`receiptTrie must be 32 bytes, received ${receiptTrie.length} bytes`)
    }
  }

  /**
   * Validates if the block gasLimit remains in the
   * boundaries set by the protocol.
   *
   * @param parentBlockHeader - the header from the parent `Block` of this header
   */
  // eslint-disable-next-line @typescript-eslint/no-unused-vars,no-unused-vars
  validateGasLimit(parentBlockHeader: BlockHeader): boolean {
    return this.gasLimit.gt(new BN(0))
  }

  /**
   * Validates the block header, throwing if invalid. It is being validated against the reported `parentHash`.
   * It verifies the current block against the `parentHash`:
   * - The `parentHash` is part of the blockchain (it is a valid header)
   * - Current block number is parent block number + 1
   * - Current block has a strictly higher timestamp
   * - Additional PoW checks ->
   *   - Current block has valid difficulty and gas limit
   *   - In case that the header is an uncle header, it should not be too old or young in the chain.
   * - Additional PoA clique checks ->
   *   - Various extraData checks
   *   - Checks on coinbase and mixHash
   *   - Current block has a timestamp diff greater or equal to PERIOD
   *   - Current block has difficulty correctly marked as INTURN or NOTURN
   * @param blockchain - validate against an @ethereumjs/blockchain
   * @param height - If this is an uncle header, this is the height of the block that is including it
   */
  // eslint-disable-next-line @typescript-eslint/no-unused-vars,no-unused-vars
  async validate(blockchain: Blockchain, height?: BN): Promise<void> {
    if (this.isGenesis()) {
      return
    }

    const parentHeader = await this._getHeaderByHash(blockchain, this.parentHash)

    if (!parentHeader) {
      throw new Error('could not find parent header')
    }

    const { number } = this
    if (!number.eq(parentHeader.number.addn(1))) {
      throw new Error('invalid number')
    }

    if (this.timestamp.lte(parentHeader.timestamp)) {
      throw new Error('invalid timestamp')
    }

    if (!this.validateGasLimit(parentHeader)) {
      throw new Error('invalid gas limit')
    }

    // check if the block used too much gas
    if (this.gasUsed.gt(this.gasLimit)) {
      throw new Error('Invalid block: too much gas used')
    }

    if (this._common.isActivatedEIP(1559)) {
      if (!this.baseFeePerGas) {
        throw new Error('EIP1559 block has no base fee field')
      }
    }
  }

  /**
   * Calculates the base fee for a potential next block
   */
  public calcNextBaseFee(): BN {
    if (!this._common.isActivatedEIP(1559)) {
      throw new Error('calcNextBaseFee() can only be called with EIP1559 being activated')
    }
    let nextBaseFee: BN
    const elasticity = new BN(this._common.param('gasConfig', 'elasticityMultiplier'))
    const parentGasTarget = this.gasLimit.div(elasticity)

    if (parentGasTarget.eq(this.gasUsed)) {
      nextBaseFee = this.baseFeePerGas!
    } else if (this.gasUsed.gt(parentGasTarget)) {
      const gasUsedDelta = this.gasUsed.sub(parentGasTarget)
      const baseFeeMaxChangeDenominator = new BN(
        this._common.param('gasConfig', 'baseFeeMaxChangeDenominator')
      )
      const calculatedDelta = this.baseFeePerGas!.mul(gasUsedDelta)
        .div(parentGasTarget)
        .div(baseFeeMaxChangeDenominator)
      nextBaseFee = BN.max(calculatedDelta, new BN(1)).add(this.baseFeePerGas!)
    } else {
      const gasUsedDelta = parentGasTarget.sub(this.gasUsed)
      const baseFeeMaxChangeDenominator = new BN(
        this._common.param('gasConfig', 'baseFeeMaxChangeDenominator')
      )
      const calculatedDelta = this.baseFeePerGas!.mul(gasUsedDelta)
        .div(parentGasTarget)
        .div(baseFeeMaxChangeDenominator)
      nextBaseFee = BN.max(this.baseFeePerGas!.sub(calculatedDelta), new BN(0))
    }
    return nextBaseFee
  }

  /**
   * Returns a Buffer Array of the raw Buffers in this header, in order.
   */
  raw(): BlockHeaderBuffer {
    const rawItems = [
      this.parentHash,
      this.coinbase.buf,
      this.stateRoot,
      this.transactionsTrie,
      this.receiptTrie,
      this.bloom,
      bnToUnpaddedBuffer(this.number),
      bnToUnpaddedBuffer(this.gasLimit),
      bnToUnpaddedBuffer(this.gasUsed),
      bnToUnpaddedBuffer(this.timestamp),
    ]

    if (this._common.isActivatedEIP(1559)) {
      rawItems.push(bnToUnpaddedBuffer(this.baseFeePerGas!))
    }

    return rawItems
  }

  /**
   * Returns the hash of the block header.
   */
  hash(): Buffer {
    return rlphash(this.raw())
  }

  /**
   * Checks if the block header is a genesis header.
   */
  isGenesis(): boolean {
    return this.number.isZero()
  }

  /**
   * Returns the rlp encoding of the block header.
   */
  serialize(): Buffer {
    return rlp.encode(this.raw())
  }

  /**
   * Returns the block header in JSON format.
   */
  toJSON(): JsonHeader {
    const jsonDict: JsonHeader = {
      parentHash: '0x' + this.parentHash.toString('hex'),
      coinbase: this.coinbase.toString(),
      stateRoot: '0x' + this.stateRoot.toString('hex'),
      transactionsTrie: '0x' + this.transactionsTrie.toString('hex'),
      receiptTrie: '0x' + this.receiptTrie.toString('hex'),
      bloom: '0x' + this.bloom.toString('hex'),
      number: bnToHex(this.number),
      gasLimit: bnToHex(this.gasLimit),
      gasUsed: bnToHex(this.gasUsed),
      timestamp: bnToHex(this.timestamp),
    }
    if (this._common.isActivatedEIP(1559)) {
      jsonDict['baseFee'] = '0x' + this.baseFeePerGas!.toString('hex')
    }

    return jsonDict
  }

  /**
   * Internal helper function to create an annotated error message
   *
   * @param msg Base error message
   * @hidden
   */
  _error(msg: string) {
    msg += ` (${this._errorPostfix})`
    const e = new Error(msg)
    return e
  }

  private async _getHeaderByHash(
    blockchain: Blockchain,
    hash: Buffer
  ): Promise<BlockHeader | undefined> {
    try {
      const header = (await blockchain.getBlock(hash)).header
      return header
    } catch (error) {
      if (error.type === 'NotFoundError') {
        return undefined
      } else {
        throw error
      }
    }
  }
}
