import { BlockHeader } from './header'
import { BlockOptions } from './types'

/**
 * Creates a new block header object from Ethereum JSON RPC.
 *
 * @param blockParams - Ethereum JSON RPC of block (eth_getBlockByNumber)
 * @param chainOptions - An object describing the blockchain
 */
export default function blockHeaderFromRpc(blockParams: any, options?: BlockOptions) {
  const {
    parentHash,
    miner,
    stateRoot,
    transactionsRoot,
    receiptRoot,
    receiptsRoot,
    logsBloom,
    number,
    gasLimit,
    gasUsed,
    timestamp,
  } = blockParams

  let baseFeePerGas

  // Check if the field baseFeePerGas is present in the block.
  // This field was introduced after: https://eips.ethereum.org/EIPS/eip-1559
  if ('baseFeePerGas' in blockParams) {
    baseFeePerGas = blockParams.baseFeePerGas
  }

  const blockHeader = BlockHeader.fromHeaderData(
    {
      parentHash,
      coinbase: miner,
      stateRoot,
      transactionsTrie: transactionsRoot,
      receiptTrie: receiptRoot || receiptsRoot,
      bloom: logsBloom,
      number,
      gasLimit,
      gasUsed,
      timestamp,
      baseFeePerGas,
    },
    options
  )

  return blockHeader
}
