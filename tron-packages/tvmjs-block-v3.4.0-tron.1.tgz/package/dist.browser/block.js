"use strict";
/* eslint-disable no-dupe-class-members */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Block = void 0;
var merkle_patricia_tree_1 = require("merkle-patricia-tree");
var util_1 = require("@tvmjs/util");
var tx_1 = require("@tvmjs/tx");
var header_1 = require("./header");
/**
 * An object that represents the block.
 */
var Block = /** @class */ (function () {
    /**
     * This constructor takes the values, validates them, assigns them and freezes the object.
     * Use the static factory methods to assist in creating a Block object from varying data types and options.
     */
    function Block(header, transactions, opts) {
        if (transactions === void 0) { transactions = []; }
        if (opts === void 0) { opts = {}; }
        var _a;
        this.transactions = [];
        this.txTrie = new merkle_patricia_tree_1.BaseTrie();
        this.header = header !== null && header !== void 0 ? header : header_1.BlockHeader.fromHeaderData({}, opts);
        this.transactions = transactions;
        this._common = this.header._common;
        var freeze = (_a = opts === null || opts === void 0 ? void 0 : opts.freeze) !== null && _a !== void 0 ? _a : true;
        if (freeze) {
            Object.freeze(this);
        }
    }
    /**
     * Static constructor to create a block from a block data dictionary
     *
     * @param blockData
     * @param opts
     */
    Block.fromBlockData = function (blockData, opts) {
        var e_1, _a;
        if (blockData === void 0) { blockData = {}; }
        var headerData = blockData.header, txsData = blockData.transactions;
        var header = header_1.BlockHeader.fromHeaderData(headerData, opts);
        // parse transactions
        var transactions = [];
        try {
            for (var _b = __values(txsData !== null && txsData !== void 0 ? txsData : []), _c = _b.next(); !_c.done; _c = _b.next()) {
                var txData = _c.value;
                var tx = tx_1.TransactionFactory.fromTxData(txData, __assign(__assign({}, opts), { 
                    // Use header common in case of hardforkByBlockNumber being activated
                    common: header._common }));
                transactions.push(tx);
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
            }
            finally { if (e_1) throw e_1.error; }
        }
        return new Block(header, transactions, opts);
    };
    /**
     * Static constructor to create a block from a RLP-serialized block
     *
     * @param serialized
     * @param opts
     */
    Block.fromRLPSerializedBlock = function (serialized, opts) {
        var values = util_1.rlp.decode(serialized);
        if (!Array.isArray(values)) {
            throw new Error('Invalid serialized block input. Must be array');
        }
        return Block.fromValuesArray(values, opts);
    };
    /**
     * Static constructor to create a block from an array of Buffer values
     *
     * @param values
     * @param opts
     */
    Block.fromValuesArray = function (values, opts) {
        var e_2, _a;
        if (values.length > 2) {
            throw new Error('invalid block. More values than expected were received');
        }
        var _b = __read(values, 2), headerData = _b[0], txsData = _b[1];
        var header = header_1.BlockHeader.fromValuesArray(headerData, opts);
        // parse transactions
        var transactions = [];
        try {
            for (var _c = __values(txsData || []), _d = _c.next(); !_d.done; _d = _c.next()) {
                var txData = _d.value;
                transactions.push(tx_1.TransactionFactory.fromBlockBodyData(txData, __assign(__assign({}, opts), { 
                    // Use header common in case of hardforkByBlockNumber being activated
                    common: header._common })));
            }
        }
        catch (e_2_1) { e_2 = { error: e_2_1 }; }
        finally {
            try {
                if (_d && !_d.done && (_a = _c.return)) _a.call(_c);
            }
            finally { if (e_2) throw e_2.error; }
        }
        return new Block(header, transactions, opts);
    };
    /**
     * Alias for {@link Block.fromBlockData} with {@link BlockOptions.initWithGenesisHeader} set to true.
     */
    Block.genesis = function (blockData, opts) {
        if (blockData === void 0) { blockData = {}; }
        opts = __assign(__assign({}, opts), { initWithGenesisHeader: true });
        return Block.fromBlockData(blockData, opts);
    };
    /**
     * Returns a Buffer Array of the raw Buffers of this block, in order.
     */
    Block.prototype.raw = function () {
        return [
            this.header.raw(),
            this.transactions.map(function (tx) {
                return tx.supports(tx_1.Capability.EIP2718TypedTransaction) ? tx.serialize() : tx.raw();
            }),
        ];
    };
    /**
     * Produces a hash the RLP of the block.
     */
    Block.prototype.hash = function () {
        return this.header.hash();
    };
    /**
     * Determines if this block is the genesis block.
     */
    Block.prototype.isGenesis = function () {
        return this.header.isGenesis();
    };
    /**
     * Returns the rlp encoding of the block.
     */
    Block.prototype.serialize = function () {
        return util_1.rlp.encode(this.raw());
    };
    /**
     * Generates transaction trie for validation.
     */
    Block.prototype.genTxTrie = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _a, transactions, txTrie, i, tx, key, value;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _a = this, transactions = _a.transactions, txTrie = _a.txTrie;
                        i = 0;
                        _b.label = 1;
                    case 1:
                        if (!(i < transactions.length)) return [3 /*break*/, 4];
                        tx = transactions[i];
                        key = util_1.rlp.encode(i);
                        value = tx.serialize();
                        return [4 /*yield*/, txTrie.put(key, value)];
                    case 2:
                        _b.sent();
                        _b.label = 3;
                    case 3:
                        i++;
                        return [3 /*break*/, 1];
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Validates the transaction trie by generating a trie
     * and do a check on the root hash.
     */
    Block.prototype.validateTransactionsTrie = function () {
        return __awaiter(this, void 0, void 0, function () {
            var result;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (this.transactions.length === 0) {
                            result = this.header.transactionsTrie.equals(util_1.KECCAK256_RLP);
                            return [2 /*return*/, result];
                        }
                        if (!this.txTrie.root.equals(util_1.KECCAK256_RLP)) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.genTxTrie()];
                    case 1:
                        _a.sent();
                        _a.label = 2;
                    case 2:
                        result = this.txTrie.root.equals(this.header.transactionsTrie);
                        return [2 /*return*/, result];
                }
            });
        });
    };
    Block.prototype.validateTransactions = function (stringError) {
        var _this = this;
        if (stringError === void 0) { stringError = false; }
        var errors = [];
        this.transactions.forEach(function (tx, i) {
            var errs = tx.validate(true);
            if (_this._common.isActivatedEIP(1559)) {
                if (tx.supports(tx_1.Capability.EIP1559FeeMarket)) {
                    tx = tx;
                    if (tx.maxFeePerGas.lt(_this.header.baseFeePerGas)) {
                        errs.push('tx unable to pay base fee (EIP-1559 tx)');
                    }
                }
                else {
                    tx = tx;
                    if (tx.gasPrice.lt(_this.header.baseFeePerGas)) {
                        errs.push('tx unable to pay base fee (non EIP-1559 tx)');
                    }
                }
            }
            if (errs.length > 0) {
                errors.push("errors at tx " + i + ": " + errs.join(', '));
            }
        });
        return stringError ? errors : errors.length === 0;
    };
    /**
     * Performs the following consistency checks on the block:
     *
     * - Value checks on the header fields
     * - Signature and gasLimit validation for included txs
     * - Validation of the tx trie
     * - Consistency checks and header validation of included uncles
     *
     * Throws if invalid.
     *
     * @param blockchain - validate against an @ethereumjs/blockchain
     * @param onlyHeader - if should only validate the header (skips validating txTrie and unclesHash) (default: false)
     */
    Block.prototype.validate = function (blockchain, onlyHeader) {
        if (onlyHeader === void 0) { onlyHeader = false; }
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.header.validate(blockchain)];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, this.validateData(onlyHeader)];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Validates the block data, throwing if invalid.
     * This can be checked on the Block itself without needing access to any parent block
     * It checks:
     * - All transactions are valid
     * - The transactions trie is valid
     * - The uncle hash is valid
     * @param onlyHeader if only passed the header, skip validating txTrie and unclesHash (default: false)
     */
    Block.prototype.validateData = function (onlyHeader) {
        if (onlyHeader === void 0) { onlyHeader = false; }
        return __awaiter(this, void 0, void 0, function () {
            var txErrors, msg, validateTxTrie;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        txErrors = this.validateTransactions(true);
                        if (txErrors.length > 0) {
                            msg = "invalid transactions: " + txErrors.join(' ');
                            throw this.header._error(msg);
                        }
                        if (!!onlyHeader) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.validateTransactionsTrie()];
                    case 1:
                        validateTxTrie = _a.sent();
                        if (!validateTxTrie) {
                            throw new Error('invalid transaction trie');
                        }
                        _a.label = 2;
                    case 2: return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Validates if the block gasLimit remains in the
     * boundaries set by the protocol.
     *
     * @param parentBlock - the parent of this `Block`
     */
    Block.prototype.validateGasLimit = function (parentBlock) {
        return this.header.validateGasLimit(parentBlock.header);
    };
    /**
     * Returns the block in JSON format.
     */
    Block.prototype.toJSON = function () {
        return {
            header: this.header.toJSON(),
            transactions: this.transactions.map(function (tx) { return tx.toJSON(); }),
        };
    };
    return Block;
}());
exports.Block = Block;
//# sourceMappingURL=block.js.map