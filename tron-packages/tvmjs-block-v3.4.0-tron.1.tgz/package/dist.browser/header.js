"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BlockHeader = void 0;
var common_1 = __importDefault(require("@tvmjs/common"));
var util_1 = require("@tvmjs/util");
var DEFAULT_GAS_LIMIT = new util_1.BN(Buffer.from('ffffffffffffff', 'hex'));
/**
 * An object that represents the block header.
 */
var BlockHeader = /** @class */ (function () {
    /**
     * This constructor takes the values, validates them, assigns them and freezes the object.
     *
     * @deprecated - Use the public static factory methods to assist in creating a Header object from
     * varying data types. For a default empty header, use {@link BlockHeader.fromHeaderData}.
     *
     */
    function BlockHeader(parentHash, coinbase, stateRoot, transactionsTrie, receiptTrie, bloom, number, gasLimit, gasUsed, timestamp, options, baseFeePerGas) {
        if (options === void 0) { options = {}; }
        var _a;
        this._errorPostfix = '';
        if (options.common) {
            this._common = options.common.copy();
        }
        else {
            var chain = 'mainnet'; // default
            if (options.initWithGenesisHeader) {
                this._common = new common_1.default({ chain: chain, hardfork: 'chainstart' });
            }
            else {
                // This initializes on the Common default hardfork
                this._common = new common_1.default({ chain: chain });
            }
        }
        if (options.hardforkByBlockNumber) {
            this._common.setHardforkByBlockNumber(number.toNumber());
        }
        if (this._common.isActivatedEIP(1559)) {
            if (baseFeePerGas === undefined) {
                baseFeePerGas = new util_1.BN(7);
            }
        }
        else {
            if (baseFeePerGas) {
                throw new Error('A base fee for a block can only be set with EIP1559 being activated');
            }
        }
        if (options.initWithGenesisHeader) {
            number = new util_1.BN(0);
            if (gasLimit.eq(DEFAULT_GAS_LIMIT)) {
                gasLimit = new util_1.BN(util_1.toBuffer(this._common.genesis().gasLimit));
            }
            if (timestamp.isZero()) {
                timestamp = new util_1.BN(util_1.toBuffer(this._common.genesis().timestamp));
            }
            if (stateRoot.equals(util_1.zeros(32))) {
                stateRoot = util_1.toBuffer(this._common.genesis().stateRoot);
            }
        }
        this.parentHash = parentHash;
        this.coinbase = coinbase;
        this.stateRoot = stateRoot;
        this.transactionsTrie = transactionsTrie;
        this.receiptTrie = receiptTrie;
        this.bloom = bloom;
        this.number = number;
        this.gasLimit = gasLimit;
        this.gasUsed = gasUsed;
        this.timestamp = timestamp;
        this.baseFeePerGas = baseFeePerGas;
        this._validateHeaderFields();
        this._errorPostfix = "block number=" + this.number.toNumber() + " hash=" + this.hash().toString('hex');
        var freeze = (_a = options === null || options === void 0 ? void 0 : options.freeze) !== null && _a !== void 0 ? _a : true;
        if (freeze) {
            Object.freeze(this);
        }
    }
    /**
     * Static constructor to create a block header from a header data dictionary
     *
     * @param headerData
     * @param opts
     */
    BlockHeader.fromHeaderData = function (headerData, opts) {
        if (headerData === void 0) { headerData = {}; }
        if (opts === void 0) { opts = {}; }
        var parentHash = headerData.parentHash, coinbase = headerData.coinbase, stateRoot = headerData.stateRoot, transactionsTrie = headerData.transactionsTrie, receiptTrie = headerData.receiptTrie, bloom = headerData.bloom, number = headerData.number, gasLimit = headerData.gasLimit, gasUsed = headerData.gasUsed, timestamp = headerData.timestamp, baseFeePerGas = headerData.baseFeePerGas;
        return new BlockHeader(parentHash ? util_1.toBuffer(parentHash) : util_1.zeros(32), coinbase ? new util_1.Address(util_1.toBuffer(coinbase)) : util_1.Address.zero(), stateRoot ? util_1.toBuffer(stateRoot) : util_1.zeros(32), transactionsTrie ? util_1.toBuffer(transactionsTrie) : util_1.KECCAK256_RLP, receiptTrie ? util_1.toBuffer(receiptTrie) : util_1.KECCAK256_RLP, bloom ? util_1.toBuffer(bloom) : util_1.zeros(256), number ? new util_1.BN(util_1.toBuffer(number)) : new util_1.BN(0), gasLimit ? new util_1.BN(util_1.toBuffer(gasLimit)) : DEFAULT_GAS_LIMIT, gasUsed ? new util_1.BN(util_1.toBuffer(gasUsed)) : new util_1.BN(0), timestamp ? new util_1.BN(util_1.toBuffer(timestamp)) : new util_1.BN(0), opts, baseFeePerGas !== undefined ? new util_1.BN(util_1.toBuffer(baseFeePerGas)) : undefined);
    };
    /**
     * Static constructor to create a block header from a RLP-serialized header
     *
     * @param headerData
     * @param opts
     */
    BlockHeader.fromRLPSerializedHeader = function (serialized, opts) {
        if (opts === void 0) { opts = {}; }
        var values = util_1.rlp.decode(serialized);
        if (!Array.isArray(values)) {
            throw new Error('Invalid serialized header input. Must be array');
        }
        return BlockHeader.fromValuesArray(values, opts);
    };
    /**
     * Static constructor to create a block header from an array of Buffer values
     *
     * @param headerData
     * @param opts
     */
    BlockHeader.fromValuesArray = function (values, opts) {
        if (opts === void 0) { opts = {}; }
        var _a = __read(values, 11), parentHash = _a[0], coinbase = _a[1], stateRoot = _a[2], transactionsTrie = _a[3], receiptTrie = _a[4], bloom = _a[5], number = _a[6], gasLimit = _a[7], gasUsed = _a[8], timestamp = _a[9], baseFeePerGas = _a[10];
        if (values.length > 11) {
            throw new Error('invalid header. More values than expected were received');
        }
        if (values.length < 10) {
            throw new Error('invalid header. Less values than expected were received');
        }
        return new BlockHeader(util_1.toBuffer(parentHash), new util_1.Address(util_1.toBuffer(coinbase)), util_1.toBuffer(stateRoot), util_1.toBuffer(transactionsTrie), util_1.toBuffer(receiptTrie), util_1.toBuffer(bloom), new util_1.BN(util_1.toBuffer(number)), new util_1.BN(util_1.toBuffer(gasLimit)), new util_1.BN(util_1.toBuffer(gasUsed)), new util_1.BN(util_1.toBuffer(timestamp)), opts, baseFeePerGas !== undefined ? new util_1.BN(util_1.toBuffer(baseFeePerGas)) : undefined);
    };
    /**
     * Alias for {@link BlockHeader.fromHeaderData} with {@link BlockOptions.initWithGenesisHeader} set to true.
     */
    BlockHeader.genesis = function (headerData, opts) {
        if (headerData === void 0) { headerData = {}; }
        opts = __assign(__assign({}, opts), { initWithGenesisHeader: true });
        return BlockHeader.fromHeaderData(headerData, opts);
    };
    /**
     * Validates correct buffer lengths, throws if invalid.
     */
    BlockHeader.prototype._validateHeaderFields = function () {
        var _a = this, parentHash = _a.parentHash, stateRoot = _a.stateRoot, transactionsTrie = _a.transactionsTrie, receiptTrie = _a.receiptTrie;
        if (parentHash.length !== 32) {
            throw new Error("parentHash must be 32 bytes, received " + parentHash.length + " bytes");
        }
        if (stateRoot.length !== 32) {
            throw new Error("stateRoot must be 32 bytes, received " + stateRoot.length + " bytes");
        }
        if (transactionsTrie.length !== 32) {
            throw new Error("transactionsTrie must be 32 bytes, received " + transactionsTrie.length + " bytes");
        }
        if (receiptTrie.length !== 32) {
            throw new Error("receiptTrie must be 32 bytes, received " + receiptTrie.length + " bytes");
        }
    };
    /**
     * Validates if the block gasLimit remains in the
     * boundaries set by the protocol.
     *
     * @param parentBlockHeader - the header from the parent `Block` of this header
     */
    // eslint-disable-next-line @typescript-eslint/no-unused-vars,no-unused-vars
    BlockHeader.prototype.validateGasLimit = function (parentBlockHeader) {
        return this.gasLimit.gt(new util_1.BN(0));
    };
    /**
     * Validates the block header, throwing if invalid. It is being validated against the reported `parentHash`.
     * It verifies the current block against the `parentHash`:
     * - The `parentHash` is part of the blockchain (it is a valid header)
     * - Current block number is parent block number + 1
     * - Current block has a strictly higher timestamp
     * - Additional PoW checks ->
     *   - Current block has valid difficulty and gas limit
     *   - In case that the header is an uncle header, it should not be too old or young in the chain.
     * - Additional PoA clique checks ->
     *   - Various extraData checks
     *   - Checks on coinbase and mixHash
     *   - Current block has a timestamp diff greater or equal to PERIOD
     *   - Current block has difficulty correctly marked as INTURN or NOTURN
     * @param blockchain - validate against an @ethereumjs/blockchain
     * @param height - If this is an uncle header, this is the height of the block that is including it
     */
    // eslint-disable-next-line @typescript-eslint/no-unused-vars,no-unused-vars
    BlockHeader.prototype.validate = function (blockchain, height) {
        return __awaiter(this, void 0, void 0, function () {
            var parentHeader, number;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (this.isGenesis()) {
                            return [2 /*return*/];
                        }
                        return [4 /*yield*/, this._getHeaderByHash(blockchain, this.parentHash)];
                    case 1:
                        parentHeader = _a.sent();
                        if (!parentHeader) {
                            throw new Error('could not find parent header');
                        }
                        number = this.number;
                        if (!number.eq(parentHeader.number.addn(1))) {
                            throw new Error('invalid number');
                        }
                        if (this.timestamp.lte(parentHeader.timestamp)) {
                            throw new Error('invalid timestamp');
                        }
                        if (!this.validateGasLimit(parentHeader)) {
                            throw new Error('invalid gas limit');
                        }
                        // check if the block used too much gas
                        if (this.gasUsed.gt(this.gasLimit)) {
                            throw new Error('Invalid block: too much gas used');
                        }
                        if (this._common.isActivatedEIP(1559)) {
                            if (!this.baseFeePerGas) {
                                throw new Error('EIP1559 block has no base fee field');
                            }
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Calculates the base fee for a potential next block
     */
    BlockHeader.prototype.calcNextBaseFee = function () {
        if (!this._common.isActivatedEIP(1559)) {
            throw new Error('calcNextBaseFee() can only be called with EIP1559 being activated');
        }
        var nextBaseFee;
        var elasticity = new util_1.BN(this._common.param('gasConfig', 'elasticityMultiplier'));
        var parentGasTarget = this.gasLimit.div(elasticity);
        if (parentGasTarget.eq(this.gasUsed)) {
            nextBaseFee = this.baseFeePerGas;
        }
        else if (this.gasUsed.gt(parentGasTarget)) {
            var gasUsedDelta = this.gasUsed.sub(parentGasTarget);
            var baseFeeMaxChangeDenominator = new util_1.BN(this._common.param('gasConfig', 'baseFeeMaxChangeDenominator'));
            var calculatedDelta = this.baseFeePerGas.mul(gasUsedDelta)
                .div(parentGasTarget)
                .div(baseFeeMaxChangeDenominator);
            nextBaseFee = util_1.BN.max(calculatedDelta, new util_1.BN(1)).add(this.baseFeePerGas);
        }
        else {
            var gasUsedDelta = parentGasTarget.sub(this.gasUsed);
            var baseFeeMaxChangeDenominator = new util_1.BN(this._common.param('gasConfig', 'baseFeeMaxChangeDenominator'));
            var calculatedDelta = this.baseFeePerGas.mul(gasUsedDelta)
                .div(parentGasTarget)
                .div(baseFeeMaxChangeDenominator);
            nextBaseFee = util_1.BN.max(this.baseFeePerGas.sub(calculatedDelta), new util_1.BN(0));
        }
        return nextBaseFee;
    };
    /**
     * Returns a Buffer Array of the raw Buffers in this header, in order.
     */
    BlockHeader.prototype.raw = function () {
        var rawItems = [
            this.parentHash,
            this.coinbase.buf,
            this.stateRoot,
            this.transactionsTrie,
            this.receiptTrie,
            this.bloom,
            util_1.bnToUnpaddedBuffer(this.number),
            util_1.bnToUnpaddedBuffer(this.gasLimit),
            util_1.bnToUnpaddedBuffer(this.gasUsed),
            util_1.bnToUnpaddedBuffer(this.timestamp),
        ];
        if (this._common.isActivatedEIP(1559)) {
            rawItems.push(util_1.bnToUnpaddedBuffer(this.baseFeePerGas));
        }
        return rawItems;
    };
    /**
     * Returns the hash of the block header.
     */
    BlockHeader.prototype.hash = function () {
        return util_1.rlphash(this.raw());
    };
    /**
     * Checks if the block header is a genesis header.
     */
    BlockHeader.prototype.isGenesis = function () {
        return this.number.isZero();
    };
    /**
     * Returns the rlp encoding of the block header.
     */
    BlockHeader.prototype.serialize = function () {
        return util_1.rlp.encode(this.raw());
    };
    /**
     * Returns the block header in JSON format.
     */
    BlockHeader.prototype.toJSON = function () {
        var jsonDict = {
            parentHash: '0x' + this.parentHash.toString('hex'),
            coinbase: this.coinbase.toString(),
            stateRoot: '0x' + this.stateRoot.toString('hex'),
            transactionsTrie: '0x' + this.transactionsTrie.toString('hex'),
            receiptTrie: '0x' + this.receiptTrie.toString('hex'),
            bloom: '0x' + this.bloom.toString('hex'),
            number: util_1.bnToHex(this.number),
            gasLimit: util_1.bnToHex(this.gasLimit),
            gasUsed: util_1.bnToHex(this.gasUsed),
            timestamp: util_1.bnToHex(this.timestamp),
        };
        if (this._common.isActivatedEIP(1559)) {
            jsonDict['baseFee'] = '0x' + this.baseFeePerGas.toString('hex');
        }
        return jsonDict;
    };
    /**
     * Internal helper function to create an annotated error message
     *
     * @param msg Base error message
     * @hidden
     */
    BlockHeader.prototype._error = function (msg) {
        msg += " (" + this._errorPostfix + ")";
        var e = new Error(msg);
        return e;
    };
    BlockHeader.prototype._getHeaderByHash = function (blockchain, hash) {
        return __awaiter(this, void 0, void 0, function () {
            var header, error_1;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        return [4 /*yield*/, blockchain.getBlock(hash)];
                    case 1:
                        header = (_a.sent()).header;
                        return [2 /*return*/, header];
                    case 2:
                        error_1 = _a.sent();
                        if (error_1.type === 'NotFoundError') {
                            return [2 /*return*/, undefined];
                        }
                        else {
                            throw error_1;
                        }
                        return [3 /*break*/, 3];
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    return BlockHeader;
}());
exports.BlockHeader = BlockHeader;
//# sourceMappingURL=header.js.map