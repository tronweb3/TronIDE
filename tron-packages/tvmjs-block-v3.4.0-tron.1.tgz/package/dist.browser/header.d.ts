/// <reference types="node" />
import Common from '@tvmjs/common';
import { Address, BN } from '@tvmjs/util';
import { HeaderData, JsonHeader, BlockHeaderBuffer, Blockchain, BlockOptions } from './types';
/**
 * An object that represents the block header.
 */
export declare class BlockHeader {
    readonly parentHash: Buffer;
    readonly coinbase: Address;
    readonly stateRoot: Buffer;
    readonly transactionsTrie: Buffer;
    readonly receiptTrie: Buffer;
    readonly bloom: Buffer;
    readonly number: BN;
    readonly gasLimit: BN;
    readonly gasUsed: BN;
    readonly timestamp: BN;
    readonly baseFeePerGas?: BN;
    readonly _common: Common;
    _errorPostfix: string;
    /**
     * Static constructor to create a block header from a header data dictionary
     *
     * @param headerData
     * @param opts
     */
    static fromHeaderData(headerData?: HeaderData, opts?: BlockOptions): BlockHeader;
    /**
     * Static constructor to create a block header from a RLP-serialized header
     *
     * @param headerData
     * @param opts
     */
    static fromRLPSerializedHeader(serialized: Buffer, opts?: BlockOptions): BlockHeader;
    /**
     * Static constructor to create a block header from an array of Buffer values
     *
     * @param headerData
     * @param opts
     */
    static fromValuesArray(values: BlockHeaderBuffer, opts?: BlockOptions): BlockHeader;
    /**
     * Alias for {@link BlockHeader.fromHeaderData} with {@link BlockOptions.initWithGenesisHeader} set to true.
     */
    static genesis(headerData?: HeaderData, opts?: BlockOptions): BlockHeader;
    /**
     * This constructor takes the values, validates them, assigns them and freezes the object.
     *
     * @deprecated - Use the public static factory methods to assist in creating a Header object from
     * varying data types. For a default empty header, use {@link BlockHeader.fromHeaderData}.
     *
     */
    constructor(parentHash: Buffer, coinbase: Address, stateRoot: Buffer, transactionsTrie: Buffer, receiptTrie: Buffer, bloom: Buffer, number: BN, gasLimit: BN, gasUsed: BN, timestamp: BN, options?: BlockOptions, baseFeePerGas?: BN);
    /**
     * Validates correct buffer lengths, throws if invalid.
     */
    _validateHeaderFields(): void;
    /**
     * Validates if the block gasLimit remains in the
     * boundaries set by the protocol.
     *
     * @param parentBlockHeader - the header from the parent `Block` of this header
     */
    validateGasLimit(parentBlockHeader: BlockHeader): boolean;
    /**
     * Validates the block header, throwing if invalid. It is being validated against the reported `parentHash`.
     * It verifies the current block against the `parentHash`:
     * - The `parentHash` is part of the blockchain (it is a valid header)
     * - Current block number is parent block number + 1
     * - Current block has a strictly higher timestamp
     * - Additional PoW checks ->
     *   - Current block has valid difficulty and gas limit
     *   - In case that the header is an uncle header, it should not be too old or young in the chain.
     * - Additional PoA clique checks ->
     *   - Various extraData checks
     *   - Checks on coinbase and mixHash
     *   - Current block has a timestamp diff greater or equal to PERIOD
     *   - Current block has difficulty correctly marked as INTURN or NOTURN
     * @param blockchain - validate against an @ethereumjs/blockchain
     * @param height - If this is an uncle header, this is the height of the block that is including it
     */
    validate(blockchain: Blockchain, height?: BN): Promise<void>;
    /**
     * Calculates the base fee for a potential next block
     */
    calcNextBaseFee(): BN;
    /**
     * Returns a Buffer Array of the raw Buffers in this header, in order.
     */
    raw(): BlockHeaderBuffer;
    /**
     * Returns the hash of the block header.
     */
    hash(): Buffer;
    /**
     * Checks if the block header is a genesis header.
     */
    isGenesis(): boolean;
    /**
     * Returns the rlp encoding of the block header.
     */
    serialize(): Buffer;
    /**
     * Returns the block header in JSON format.
     */
    toJSON(): JsonHeader;
    /**
     * Internal helper function to create an annotated error message
     *
     * @param msg Base error message
     * @hidden
     */
    _error(msg: string): Error;
    private _getHeaderByHash;
}
