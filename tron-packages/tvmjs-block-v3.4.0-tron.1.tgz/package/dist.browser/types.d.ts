/// <reference types="node" />
import { AddressLike, BNLike, BufferLike } from '@tvmjs/util';
import Common from '@tvmjs/common';
import { TxData, JsonTx, AccessListEIP2930TxData, FeeMarketEIP1559TxData } from '@tvmjs/tx';
import { Block } from './block';
/**
 * An object to set to which blockchain the blocks and their headers belong. This could be specified
 * using a {@link Common} object, or `chain` and `hardfork`. Defaults to mainnet without specifying a
 * hardfork.
 */
export interface BlockOptions {
    /**
     * A {@link Common} object defining the chain and the hardfork a block/block header belongs to.
     *
     * Object will be internally copied so that tx behavior don't incidentally
     * change on future HF changes.
     *
     * Default: {@link Common} object set to `mainnet` and the HF currently defined as the default
     * hardfork in the {@link Common} class.
     *
     * Current default hardfork: `istanbul`
     */
    common?: Common;
    /**
     * Determine the HF by the block number
     *
     * Default: `false` (HF is set to whatever default HF is set by the {@link Common} instance)
     */
    hardforkByBlockNumber?: boolean;
    /**
     * Turns the block header into the canonical genesis block header
     *
     * If set to `true` all other header data is ignored.
     *
     * If a {@link Common} instance is passed the instance need to be set to `chainstart` as a HF,
     * otherwise usage of this option will throw
     *
     * Default: `false`
     */
    initWithGenesisHeader?: boolean;
    /**
     * A block object by default gets frozen along initialization. This gives you
     * strong additional security guarantees on the consistency of the block parameters.
     *
     * If you need to deactivate the block freeze - e.g. because you want to subclass block and
     * add aditional properties - it is strongly encouraged that you do the freeze yourself
     * within your code instead.
     *
     * Default: true
     */
    freeze?: boolean;
}
/**
 * A block header's data.
 */
export interface HeaderData {
    parentHash?: BufferLike;
    coinbase?: AddressLike;
    stateRoot?: BufferLike;
    transactionsTrie?: BufferLike;
    receiptTrie?: BufferLike;
    bloom?: BufferLike;
    number?: BNLike;
    gasLimit?: BNLike;
    gasUsed?: BNLike;
    timestamp?: BNLike;
    baseFeePerGas?: BNLike;
}
/**
 * A block's data.
 */
export interface BlockData {
    /**
     * Header data for the block
     */
    header?: HeaderData;
    transactions?: Array<TxData | AccessListEIP2930TxData | FeeMarketEIP1559TxData>;
}
export declare type BlockBuffer = [BlockHeaderBuffer, TransactionsBuffer];
export declare type BlockHeaderBuffer = Buffer[];
export declare type BlockBodyBuffer = [TransactionsBuffer];
/**
 * TransactionsBuffer can be an array of serialized txs for Typed Transactions or an array of Buffer Arrays for legacy transactions.
 */
export declare type TransactionsBuffer = Buffer[][] | Buffer[];
/**
 * An object with the block's data represented as strings.
 */
export interface JsonBlock {
    /**
     * Header data for the block
     */
    header?: JsonHeader;
    transactions?: JsonTx[];
}
/**
 * An object with the block header's data represented as strings.
 */
export interface JsonHeader {
    parentHash?: string;
    coinbase?: string;
    stateRoot?: string;
    transactionsTrie?: string;
    receiptTrie?: string;
    bloom?: string;
    number?: string;
    gasLimit?: string;
    gasUsed?: string;
    timestamp?: string;
    baseFee?: string;
}
export interface Blockchain {
    getBlock(hash: Buffer): Promise<Block>;
}
