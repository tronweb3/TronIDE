"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var header_1 = require("./header");
/**
 * Creates a new block header object from Ethereum JSON RPC.
 *
 * @param blockParams - Ethereum JSON RPC of block (eth_getBlockByNumber)
 * @param chainOptions - An object describing the blockchain
 */
function blockHeaderFromRpc(blockParams, options) {
    var parentHash = blockParams.parentHash, miner = blockParams.miner, stateRoot = blockParams.stateRoot, transactionsRoot = blockParams.transactionsRoot, receiptRoot = blockParams.receiptRoot, receiptsRoot = blockParams.receiptsRoot, logsBloom = blockParams.logsBloom, number = blockParams.number, gasLimit = blockParams.gasLimit, gasUsed = blockParams.gasUsed, timestamp = blockParams.timestamp;
    var baseFeePerGas;
    // Check if the field baseFeePerGas is present in the block.
    // This field was introduced after: https://eips.ethereum.org/EIPS/eip-1559
    if ('baseFeePerGas' in blockParams) {
        baseFeePerGas = blockParams.baseFeePerGas;
    }
    var blockHeader = header_1.BlockHeader.fromHeaderData({
        parentHash: parentHash,
        coinbase: miner,
        stateRoot: stateRoot,
        transactionsTrie: transactionsRoot,
        receiptTrie: receiptRoot || receiptsRoot,
        bloom: logsBloom,
        number: number,
        gasLimit: gasLimit,
        gasUsed: gasUsed,
        timestamp: timestamp,
        baseFeePerGas: baseFeePerGas,
    }, options);
    return blockHeader;
}
exports.default = blockHeaderFromRpc;
//# sourceMappingURL=header-from-rpc.js.map