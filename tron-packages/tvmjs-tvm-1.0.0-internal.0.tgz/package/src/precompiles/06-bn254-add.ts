import { bytesToHex, setLengthRight } from '@tvmjs/util'

import { OOGResult, TVMErrorResult } from '../tvm.ts'

import { getPrecompileName } from './index.ts'
import { gasLimitCheck } from './util.ts'

import type { TVM } from '../tvm.ts'
import type { ExecResult } from '../types.ts'
import type { PrecompileInput } from './types.ts'

export function precompile06(opts: PrecompileInput): ExecResult {
  const pName = getPrecompileName('06')
  const gasUsed = opts.common.param('bn254AddGas')
  if (!gasLimitCheck(opts, gasUsed, pName)) {
    return OOGResult(opts.gasLimit)
  }

  // > 128 bytes: chop off extra bytes
  // < 128 bytes: right-pad with 0-s
  const input = setLengthRight(opts.data.subarray(0, 128), 128)

  let returnData
  try {
    returnData = (opts._TVM as TVM)['_bn254'].add(input)
  } catch (e: any) {
    if (opts._debug !== undefined) {
      opts._debug(`${pName} failed: ${e.message}`)
    }
    return TVMErrorResult(e, opts.gasLimit)
  }

  // check ecadd success or failure by comparing the output length
  if (returnData.length !== 64) {
    if (opts._debug !== undefined) {
      opts._debug(`${pName} failed: OOG`)
    }
    return OOGResult(opts.gasLimit)
  }

  if (opts._debug !== undefined) {
    opts._debug(`${pName} return value=${bytesToHex(returnData)}`)
  }

  return {
    executionGasUsed: gasUsed,
    returnValue: returnData,
  }
}
