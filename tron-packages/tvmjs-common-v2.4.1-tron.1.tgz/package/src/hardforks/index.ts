export const hardforks = [
  ['chainstart', require('./chainstart.json')],
  ['homestead', require('./homestead.json')],
  ['dao', require('./dao.json')],
  ['tangerineWhistle', require('./tangerineWhistle.json')],
  ['spuriousDragon', require('./spuriousDragon.json')],
  ['byzantium', require('./byzantium.json')],
  ['constantinople', require('./constantinople.json')],
  ['petersburg', require('./petersburg.json')],
  ['istanbul', require('./istanbul.json')],
  ['muirGlacier', require('./muirGlacier.json')],
  ['berlin', require('./berlin.json')],
  ['london', require('./london.json')],
  ['shanghai', require('./shanghai.json')],
]

export const tronHardforks = [
  ['chainstart', require('./chainstart.json')],
  ['homestead', require('./homestead.json')],
  ['tangerineWhistle', require('./tangerineWhistle.json')],
  ['spuriousDragon', require('./spuriousDragon.json')],
  ['byzantium', require('./byzantium.json')],
  ['constantinople', require('./constantinople.json')],
  ['petersburg', require('./petersburg.json')],
  ['istanbul', require('./istanbul.json')],
  ['tron', require('./tron.json')],
]
