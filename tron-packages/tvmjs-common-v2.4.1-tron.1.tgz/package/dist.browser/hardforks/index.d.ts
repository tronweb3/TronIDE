export declare const hardforks: any[][];
export declare const tronHardforks: any[][];
