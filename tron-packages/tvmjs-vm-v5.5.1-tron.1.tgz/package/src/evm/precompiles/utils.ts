import { Buffer } from 'buffer'
import { BN, ecrecover, publicToAddress, ECDSASignature } from '@tvmjs/util'

import { DataWord } from './dataWord'

export function extractBytesArray(words: DataWord[], offset: number, data: Buffer): Buffer[] {
  if (offset > words.length - 1) {
    return []
  }

  const len = words[offset].intValueSafe()
  const result = new Array<Buffer>(len)
  for (let i = 0; i < len; ++i) {
    const bytesOffset = words[offset + i + 1].intValueSafe() / DataWord.WORD_SIZE
    const bytesLen = words[offset + bytesOffset + 1].intValueSafe()
    const bytes = Buffer.alloc(bytesLen)
    const start = (bytesOffset + offset + 2) * DataWord.WORD_SIZE
    const end = start + bytesLen
    data.copy(bytes, 0, start, end)
    result[i] = bytes
  }
  return result
}

export function extractBytes32Array(words: DataWord[], offset: number): Buffer[] {
  const len = words[offset].intValueSafe()
  const result = new Array(len)
  for (let i = 0; i < len; ++i) {
    result[i] = words[offset + i + 1].data
  }
  return result
}

export function recoverAddrBySign(sign: Buffer, hash: Buffer) {
  const r = sign.slice(0, 32)
  const s = sign.slice(32, 64)
  let v = sign[64]

  if (v < 27) {
    v += 27
  }

  try {
    const publicKey = ecrecover(hash, new BN(v), r, s)
    return publicToAddress(publicKey)
  } catch (e) {
    return Buffer.alloc(0)
  }
}

export function convertToTronAddress(address: Buffer): Buffer {
  if (address.length == 20) {
    const newAddress = Buffer.alloc(21)
    newAddress[0] = isMainnet() ? 0x41 : 0xa0
    address.copy(newAddress, 1, 0, address.length)
    return newAddress
  }
  return address
}

export function bufferFromInt(num: number): Buffer {
  return Buffer.from([(num >> 24) & 255, (num >> 16) & 255, (num >> 8) & 255, num & 255])
}

export function isMainnet(): boolean {
  return process.env.IS_TESTNET != '1'
}

export function ecsignToBuffer(sign: ECDSASignature): Buffer {
  const fixedV = Buffer.alloc(1, sign.v >= 27 ? sign.v - 27 : sign.v)
  return Buffer.concat([sign.r, sign.s, fixedV])
}
