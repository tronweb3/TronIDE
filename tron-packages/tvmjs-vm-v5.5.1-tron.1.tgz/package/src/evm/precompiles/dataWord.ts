import { BN } from '@tvmjs/util'

export class DataWord {
  static readonly WORD_SIZE = 32

  private readonly _data: Buffer

  constructor(buffer: Buffer) {
    this._data = Buffer.alloc(DataWord.WORD_SIZE)
    buffer.copy(this._data, 0, 0, DataWord.WORD_SIZE)
    return this
  }

  static parseArray(data: Buffer): DataWord[] {
    const len = data.length / DataWord.WORD_SIZE
    const words = new Array(len)

    for (let i = 0; i < len; ++i) {
      const start = i * DataWord.WORD_SIZE
      const buffer = data.slice(start, start + DataWord.WORD_SIZE)
      words[i] = new DataWord(buffer)
    }
    return words
  }

  get data() {
    return this._data
  }

  intValueSafe(): number {
    const firstNonZero = this._data.findIndex((ele) => ele != 0)
    let bytesOccupied = 0
    if (firstNonZero != -1) {
      bytesOccupied = DataWord.WORD_SIZE - firstNonZero + 1
    }

    const intValue = this.intValue()
    if (bytesOccupied > 4 || intValue < 0) {
      return new BN(2).pow(new BN(256)).sub(new BN(1)).toNumber()
    }
    return intValue
  }

  intValue(): number {
    let intVal = 0

    this._data.forEach((ele) => {
      intVal = (intVal << 8) + (ele & 0xff)
    })

    return intVal
  }

  static equalAddressByteArray(arr1: Buffer, arr2: Buffer): boolean {
    if (arr1 === arr2) {
      return true
    }
    if (arr1.length < 20 || arr2.length < 20) {
      return false
    }

    let i = arr1.length - 20
    let j = arr2.length - 20
    for (; i < arr1.length && j < arr2.length; ++i, ++j) {
      if (arr1[i] != arr2[j]) {
        return false
      }
    }
    return true
  }

  getLast20Bytes(): Buffer {
    const result = Buffer.alloc(20)
    this._data.copy(result, 0, 12, DataWord.WORD_SIZE)
    return result
  }
}
