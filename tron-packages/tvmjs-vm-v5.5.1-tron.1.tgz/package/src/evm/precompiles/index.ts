import { Address } from '@tvmjs/util'
import Common from '@tvmjs/common'
import { PrecompileInput, PrecompileFunc } from './types'
import { default as p1 } from './01-ecrecover'
import { default as p2 } from './02-sha256'
import { default as p3 } from './03-ripemd160'
import { default as p4 } from './04-identity'
import { default as p5 } from './05-modexp'
import { default as p6 } from './06-ecadd'
import { default as p7 } from './07-ecmul'
import { default as p8 } from './08-ecpairing'
import { default as p9 } from './09-batch-validate-sign'
import { default as pa } from './0a-validate-multi-sign'

interface Precompiles {
  [key: string]: PrecompileFunc
}

interface PrecompileAvailability {
  [key: string]: PrecompileAvailabilityCheckType
}

type PrecompileAvailabilityCheckType =
  | PrecompileAvailabilityCheckTypeHardfork
  | PrecompileAvailabilityCheckTypeEIP

enum PrecompileAvailabilityCheck {
  EIP,
  Hardfork,
}

interface PrecompileAvailabilityCheckTypeHardfork {
  type: PrecompileAvailabilityCheck.Hardfork
  param: string
}

interface PrecompileAvailabilityCheckTypeEIP {
  type: PrecompileAvailabilityCheck.EIP
  param: number
}

const ripemdPrecompileAddress = '0000000000000000000000000000000000000003'
const precompiles: Precompiles = {
  '0000000000000000000000000000000000000001': p1,
  '0000000000000000000000000000000000000002': p2,
  [ripemdPrecompileAddress]: p3,
  '0000000000000000000000000000000000000004': p4,
  '0000000000000000000000000000000000000005': p5,
  '0000000000000000000000000000000000000006': p6,
  '0000000000000000000000000000000000000007': p7,
  '0000000000000000000000000000000000000008': p8,
  '0000000000000000000000000000000000000009': p9,
  '000000000000000000000000000000000000000a': pa,
}

const precompileAvailability: PrecompileAvailability = {
  '0000000000000000000000000000000000000001': {
    type: PrecompileAvailabilityCheck.Hardfork,
    param: 'tron',
  },
  '0000000000000000000000000000000000000002': {
    type: PrecompileAvailabilityCheck.Hardfork,
    param: 'tron',
  },
  [ripemdPrecompileAddress]: {
    type: PrecompileAvailabilityCheck.Hardfork,
    param: 'tron',
  },
  '0000000000000000000000000000000000000004': {
    type: PrecompileAvailabilityCheck.Hardfork,
    param: 'tron',
  },
  '0000000000000000000000000000000000000005': {
    type: PrecompileAvailabilityCheck.Hardfork,
    param: 'tron',
  },
  '0000000000000000000000000000000000000006': {
    type: PrecompileAvailabilityCheck.Hardfork,
    param: 'tron',
  },
  '0000000000000000000000000000000000000007': {
    type: PrecompileAvailabilityCheck.Hardfork,
    param: 'tron',
  },
  '0000000000000000000000000000000000000008': {
    type: PrecompileAvailabilityCheck.Hardfork,
    param: 'tron',
  },
  '0000000000000000000000000000000000000009': {
    type: PrecompileAvailabilityCheck.Hardfork,
    param: 'tron',
  },
  '000000000000000000000000000000000000000a': {
    type: PrecompileAvailabilityCheck.Hardfork,
    param: 'tron',
  },
}

function getPrecompile(address: Address, common: Common): PrecompileFunc {
  const addr = address.buf.toString('hex')
  if (precompiles[addr]) {
    const availability = precompileAvailability[addr]
    if (
      (availability.type == PrecompileAvailabilityCheck.Hardfork &&
        common.gteHardfork(availability.param)) ||
      (availability.type == PrecompileAvailabilityCheck.EIP &&
        common.eips().includes(availability.param))
    ) {
      return precompiles[addr]
    }
  }
  return precompiles['']
}

function getActivePrecompiles(common: Common): Address[] {
  const activePrecompiles: Address[] = []
  for (const addressString in precompiles) {
    const address = new Address(Buffer.from(addressString, 'hex'))
    if (getPrecompile(address, common)) {
      activePrecompiles.push(address)
    }
  }
  return activePrecompiles
}

export {
  precompiles,
  getPrecompile,
  PrecompileFunc,
  PrecompileInput,
  ripemdPrecompileAddress,
  getActivePrecompiles,
}
