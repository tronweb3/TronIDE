import { Buffer } from 'buffer'
import { BN } from '@tvmjs/util'
import assert from 'assert'

import { DataWord } from './dataWord'
import { PrecompileInput } from './types'
import { ExecResult, OOGResult } from '../evm'
import { extractBytes32Array, extractBytesArray, recoverAddrBySign } from './utils'

export default function (opts: PrecompileInput): ExecResult {
  assert(opts.data)

  const data = opts.data

  const ENGERYPERSIGN = opts._common.param('gasPrices', 'batchValidateSign')
  const MAX_SIZE = 16
  const cnt = Math.floor((Math.floor(data.length / DataWord.WORD_SIZE) - 5) / 6)
  const gasUsed = new BN(cnt * ENGERYPERSIGN)

  if (opts.gasLimit.lt(gasUsed)) {
    return OOGResult(opts.gasLimit)
  }

  const words = DataWord.parseArray(data)

  const hash = words[0].data

  const signatures = extractBytesArray(words, words[1].intValueSafe() / DataWord.WORD_SIZE, data)
  const addresses = extractBytes32Array(words, words[2].intValueSafe() / DataWord.WORD_SIZE)

  // check length
  const length = signatures.length
  const returnValue = Buffer.alloc(DataWord.WORD_SIZE, 0)
  if (length == 0 || length > MAX_SIZE || length != addresses.length) {
    return {
      gasUsed,
      returnValue,
    }
  }

  for (let i = 0; i < length; ++i) {
    const address = addresses[i]
    const recoveredAddr = recoverAddrBySign(signatures[i], hash)
    if (DataWord.equalAddressByteArray(address, recoveredAddr)) {
      returnValue[i] = 1
    }
  }

  return {
    gasUsed,
    returnValue,
  }
}
