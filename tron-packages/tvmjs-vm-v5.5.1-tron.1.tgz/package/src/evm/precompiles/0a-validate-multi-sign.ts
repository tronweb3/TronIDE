import { Buffer } from 'buffer'
import { Address, BN, Permission, sha256 } from '@tvmjs/util'
import assert from 'assert'

import { DataWord } from './dataWord'
import { PrecompileInput } from './types'
import { ExecResult, OOGResult } from '../evm'
import { bufferFromInt, convertToTronAddress, extractBytesArray, recoverAddrBySign } from './utils'

export default async function (opts: PrecompileInput): Promise<ExecResult> {
  assert(opts.data)

  const rawData = opts.data
  const vm = opts._VM

  const ENGERYPERSIGN = opts._common.param('gasPrices', 'validateMultiSign')
  const MAX_SIZE = 5
  const cnt = Math.floor((Math.floor(rawData.length / DataWord.WORD_SIZE) - 5) / 5)
  const gasUsed = new BN(cnt * ENGERYPERSIGN)

  if (opts.gasLimit.lt(gasUsed)) {
    return OOGResult(opts.gasLimit)
  }

  const words = DataWord.parseArray(rawData)

  const addr = words[0].getLast20Bytes()
  const permissionId = words[1].intValueSafe()
  const data = words[2].data

  const tronAddr = convertToTronAddress(addr)
  const combine = Buffer.concat([tronAddr, bufferFromInt(permissionId), data])

  const hash = sha256(combine)

  const signatures = extractBytesArray(words, words[3].intValueSafe() / DataWord.WORD_SIZE, rawData)

  if (signatures.length == 0 || signatures.length > MAX_SIZE) {
    return {
      gasUsed,
      returnValue: Buffer.alloc(DataWord.WORD_SIZE, 0),
    }
  }

  const address = new Address(addr)
  const account = await vm.stateManager.getAccount(address)

  if (account) {
    try {
      const permission = account.getPermissionById(permissionId)
      if (permission) {
        let totalWeight = 0
        const executedSignList = new Set()
        for (const sign of signatures) {
          const signHexStr = sign.toString('hex')
          if (executedSignList.has(signHexStr)) {
            continue
          }
          const recoveredAddr = recoverAddrBySign(sign, hash)

          const weight = getWeight(permission, recoveredAddr)
          if (weight == 0) {
            return {
              gasUsed,
              returnValue: Buffer.alloc(DataWord.WORD_SIZE, 0),
            }
          }

          totalWeight += weight
          executedSignList.add(signHexStr)
        }

        if (totalWeight >= permission.threshold) {
          const returnValue = Buffer.alloc(DataWord.WORD_SIZE, 0)
          returnValue[DataWord.WORD_SIZE - 1] = 1
          return {
            gasUsed,
            returnValue,
          }
        }
      }
    } catch (e) {
      // ignore
    }
  }

  const returnData = Buffer.alloc(DataWord.WORD_SIZE, 0)

  return {
    gasUsed,
    returnValue: returnData,
  }
}

function getWeight(permission: Permission, address: Buffer) {
  const keys = permission.keys
  for (const key of keys) {
    if (DataWord.equalAddressByteArray(key.address, address)) {
      return key.weight
    }
  }
  return 0
}
