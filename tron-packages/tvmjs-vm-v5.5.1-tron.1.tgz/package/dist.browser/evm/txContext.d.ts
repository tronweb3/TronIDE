import { Address, BN } from '@tvmjs/util';
export default class TxContext {
    gasPrice: BN;
    origin: Address;
    constructor(gasPrice: BN, origin: Address);
}
