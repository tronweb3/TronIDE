"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var _a, _b;
Object.defineProperty(exports, "__esModule", { value: true });
exports.getActivePrecompiles = exports.ripemdPrecompileAddress = exports.getPrecompile = exports.precompiles = void 0;
var util_1 = require("@tvmjs/util");
var _01_ecrecover_1 = __importDefault(require("./01-ecrecover"));
var _02_sha256_1 = __importDefault(require("./02-sha256"));
var _03_ripemd160_1 = __importDefault(require("./03-ripemd160"));
var _04_identity_1 = __importDefault(require("./04-identity"));
var _05_modexp_1 = __importDefault(require("./05-modexp"));
var _06_ecadd_1 = __importDefault(require("./06-ecadd"));
var _07_ecmul_1 = __importDefault(require("./07-ecmul"));
var _08_ecpairing_1 = __importDefault(require("./08-ecpairing"));
var _09_batch_validate_sign_1 = __importDefault(require("./09-batch-validate-sign"));
var _0a_validate_multi_sign_1 = __importDefault(require("./0a-validate-multi-sign"));
var PrecompileAvailabilityCheck;
(function (PrecompileAvailabilityCheck) {
    PrecompileAvailabilityCheck[PrecompileAvailabilityCheck["EIP"] = 0] = "EIP";
    PrecompileAvailabilityCheck[PrecompileAvailabilityCheck["Hardfork"] = 1] = "Hardfork";
})(PrecompileAvailabilityCheck || (PrecompileAvailabilityCheck = {}));
var ripemdPrecompileAddress = '0000000000000000000000000000000000000003';
exports.ripemdPrecompileAddress = ripemdPrecompileAddress;
var precompiles = (_a = {
        '0000000000000000000000000000000000000001': _01_ecrecover_1.default,
        '0000000000000000000000000000000000000002': _02_sha256_1.default
    },
    _a[ripemdPrecompileAddress] = _03_ripemd160_1.default,
    _a['0000000000000000000000000000000000000004'] = _04_identity_1.default,
    _a['0000000000000000000000000000000000000005'] = _05_modexp_1.default,
    _a['0000000000000000000000000000000000000006'] = _06_ecadd_1.default,
    _a['0000000000000000000000000000000000000007'] = _07_ecmul_1.default,
    _a['0000000000000000000000000000000000000008'] = _08_ecpairing_1.default,
    _a['0000000000000000000000000000000000000009'] = _09_batch_validate_sign_1.default,
    _a['000000000000000000000000000000000000000a'] = _0a_validate_multi_sign_1.default,
    _a);
exports.precompiles = precompiles;
var precompileAvailability = (_b = {
        '0000000000000000000000000000000000000001': {
            type: PrecompileAvailabilityCheck.Hardfork,
            param: 'tron',
        },
        '0000000000000000000000000000000000000002': {
            type: PrecompileAvailabilityCheck.Hardfork,
            param: 'tron',
        }
    },
    _b[ripemdPrecompileAddress] = {
        type: PrecompileAvailabilityCheck.Hardfork,
        param: 'tron',
    },
    _b['0000000000000000000000000000000000000004'] = {
        type: PrecompileAvailabilityCheck.Hardfork,
        param: 'tron',
    },
    _b['0000000000000000000000000000000000000005'] = {
        type: PrecompileAvailabilityCheck.Hardfork,
        param: 'tron',
    },
    _b['0000000000000000000000000000000000000006'] = {
        type: PrecompileAvailabilityCheck.Hardfork,
        param: 'tron',
    },
    _b['0000000000000000000000000000000000000007'] = {
        type: PrecompileAvailabilityCheck.Hardfork,
        param: 'tron',
    },
    _b['0000000000000000000000000000000000000008'] = {
        type: PrecompileAvailabilityCheck.Hardfork,
        param: 'tron',
    },
    _b['0000000000000000000000000000000000000009'] = {
        type: PrecompileAvailabilityCheck.Hardfork,
        param: 'tron',
    },
    _b['000000000000000000000000000000000000000a'] = {
        type: PrecompileAvailabilityCheck.Hardfork,
        param: 'tron',
    },
    _b);
function getPrecompile(address, common) {
    var addr = address.buf.toString('hex');
    if (precompiles[addr]) {
        var availability = precompileAvailability[addr];
        if ((availability.type == PrecompileAvailabilityCheck.Hardfork &&
            common.gteHardfork(availability.param)) ||
            (availability.type == PrecompileAvailabilityCheck.EIP &&
                common.eips().includes(availability.param))) {
            return precompiles[addr];
        }
    }
    return precompiles[''];
}
exports.getPrecompile = getPrecompile;
function getActivePrecompiles(common) {
    var activePrecompiles = [];
    for (var addressString in precompiles) {
        var address = new util_1.Address(Buffer.from(addressString, 'hex'));
        if (getPrecompile(address, common)) {
            activePrecompiles.push(address);
        }
    }
    return activePrecompiles;
}
exports.getActivePrecompiles = getActivePrecompiles;
//# sourceMappingURL=index.js.map