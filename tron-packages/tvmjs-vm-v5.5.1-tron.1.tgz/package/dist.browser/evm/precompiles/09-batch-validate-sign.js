"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var buffer_1 = require("buffer");
var util_1 = require("@tvmjs/util");
var assert_1 = __importDefault(require("assert"));
var dataWord_1 = require("./dataWord");
var evm_1 = require("../evm");
var utils_1 = require("./utils");
function default_1(opts) {
    assert_1.default(opts.data);
    var data = opts.data;
    var ENGERYPERSIGN = opts._common.param('gasPrices', 'batchValidateSign');
    var MAX_SIZE = 16;
    var cnt = Math.floor((Math.floor(data.length / dataWord_1.DataWord.WORD_SIZE) - 5) / 6);
    var gasUsed = new util_1.BN(cnt * ENGERYPERSIGN);
    if (opts.gasLimit.lt(gasUsed)) {
        return evm_1.OOGResult(opts.gasLimit);
    }
    var words = dataWord_1.DataWord.parseArray(data);
    var hash = words[0].data;
    var signatures = utils_1.extractBytesArray(words, words[1].intValueSafe() / dataWord_1.DataWord.WORD_SIZE, data);
    var addresses = utils_1.extractBytes32Array(words, words[2].intValueSafe() / dataWord_1.DataWord.WORD_SIZE);
    // check length
    var length = signatures.length;
    var returnValue = buffer_1.Buffer.alloc(dataWord_1.DataWord.WORD_SIZE, 0);
    if (length == 0 || length > MAX_SIZE || length != addresses.length) {
        return {
            gasUsed: gasUsed,
            returnValue: returnValue,
        };
    }
    for (var i = 0; i < length; ++i) {
        var address = addresses[i];
        var recoveredAddr = utils_1.recoverAddrBySign(signatures[i], hash);
        if (dataWord_1.DataWord.equalAddressByteArray(address, recoveredAddr)) {
            returnValue[i] = 1;
        }
    }
    return {
        gasUsed: gasUsed,
        returnValue: returnValue,
    };
}
exports.default = default_1;
//# sourceMappingURL=09-batch-validate-sign.js.map