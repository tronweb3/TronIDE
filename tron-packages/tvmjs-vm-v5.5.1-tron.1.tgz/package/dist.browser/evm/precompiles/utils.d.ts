/// <reference types="node" />
import { ECDSASignature } from '@tvmjs/util';
import { DataWord } from './dataWord';
export declare function extractBytesArray(words: DataWord[], offset: number, data: Buffer): Buffer[];
export declare function extractBytes32Array(words: DataWord[], offset: number): Buffer[];
export declare function recoverAddrBySign(sign: Buffer, hash: Buffer): Buffer;
export declare function convertToTronAddress(address: Buffer): Buffer;
export declare function bufferFromInt(num: number): Buffer;
export declare function isMainnet(): boolean;
export declare function ecsignToBuffer(sign: ECDSASignature): Buffer;
