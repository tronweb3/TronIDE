"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ecsignToBuffer = exports.isMainnet = exports.bufferFromInt = exports.convertToTronAddress = exports.recoverAddrBySign = exports.extractBytes32Array = exports.extractBytesArray = void 0;
var buffer_1 = require("buffer");
var util_1 = require("@tvmjs/util");
var dataWord_1 = require("./dataWord");
function extractBytesArray(words, offset, data) {
    if (offset > words.length - 1) {
        return [];
    }
    var len = words[offset].intValueSafe();
    var result = new Array(len);
    for (var i = 0; i < len; ++i) {
        var bytesOffset = words[offset + i + 1].intValueSafe() / dataWord_1.DataWord.WORD_SIZE;
        var bytesLen = words[offset + bytesOffset + 1].intValueSafe();
        var bytes = buffer_1.Buffer.alloc(bytesLen);
        var start = (bytesOffset + offset + 2) * dataWord_1.DataWord.WORD_SIZE;
        var end = start + bytesLen;
        data.copy(bytes, 0, start, end);
        result[i] = bytes;
    }
    return result;
}
exports.extractBytesArray = extractBytesArray;
function extractBytes32Array(words, offset) {
    var len = words[offset].intValueSafe();
    var result = new Array(len);
    for (var i = 0; i < len; ++i) {
        result[i] = words[offset + i + 1].data;
    }
    return result;
}
exports.extractBytes32Array = extractBytes32Array;
function recoverAddrBySign(sign, hash) {
    var r = sign.slice(0, 32);
    var s = sign.slice(32, 64);
    var v = sign[64];
    if (v < 27) {
        v += 27;
    }
    try {
        var publicKey = util_1.ecrecover(hash, new util_1.BN(v), r, s);
        return util_1.publicToAddress(publicKey);
    }
    catch (e) {
        return buffer_1.Buffer.alloc(0);
    }
}
exports.recoverAddrBySign = recoverAddrBySign;
function convertToTronAddress(address) {
    if (address.length == 20) {
        var newAddress = buffer_1.Buffer.alloc(21);
        newAddress[0] = isMainnet() ? 0x41 : 0xa0;
        address.copy(newAddress, 1, 0, address.length);
        return newAddress;
    }
    return address;
}
exports.convertToTronAddress = convertToTronAddress;
function bufferFromInt(num) {
    return buffer_1.Buffer.from([(num >> 24) & 255, (num >> 16) & 255, (num >> 8) & 255, num & 255]);
}
exports.bufferFromInt = bufferFromInt;
function isMainnet() {
    return process.env.IS_TESTNET != '1';
}
exports.isMainnet = isMainnet;
function ecsignToBuffer(sign) {
    var fixedV = buffer_1.Buffer.alloc(1, sign.v >= 27 ? sign.v - 27 : sign.v);
    return buffer_1.Buffer.concat([sign.r, sign.s, fixedV]);
}
exports.ecsignToBuffer = ecsignToBuffer;
//# sourceMappingURL=utils.js.map