/// <reference types="node" />
export declare class DataWord {
    static readonly WORD_SIZE = 32;
    private readonly _data;
    constructor(buffer: Buffer);
    static parseArray(data: Buffer): DataWord[];
    get data(): Buffer;
    intValueSafe(): number;
    intValue(): number;
    static equalAddressByteArray(arr1: Buffer, arr2: Buffer): boolean;
    getLast20Bytes(): Buffer;
}
