"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var buffer_1 = require("buffer");
var util_1 = require("@tvmjs/util");
var assert_1 = __importDefault(require("assert"));
var dataWord_1 = require("./dataWord");
var evm_1 = require("../evm");
var utils_1 = require("./utils");
function default_1(opts) {
    return __awaiter(this, void 0, void 0, function () {
        var rawData, vm, ENGERYPERSIGN, MAX_SIZE, cnt, gasUsed, words, addr, permissionId, data, tronAddr, combine, hash, signatures, address, account, permission, totalWeight, executedSignList, signatures_1, signatures_1_1, sign, signHexStr, recoveredAddr, weight, returnValue, returnData;
        var e_1, _a;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    assert_1.default(opts.data);
                    rawData = opts.data;
                    vm = opts._VM;
                    ENGERYPERSIGN = opts._common.param('gasPrices', 'validateMultiSign');
                    MAX_SIZE = 5;
                    cnt = Math.floor((Math.floor(rawData.length / dataWord_1.DataWord.WORD_SIZE) - 5) / 5);
                    gasUsed = new util_1.BN(cnt * ENGERYPERSIGN);
                    if (opts.gasLimit.lt(gasUsed)) {
                        return [2 /*return*/, evm_1.OOGResult(opts.gasLimit)];
                    }
                    words = dataWord_1.DataWord.parseArray(rawData);
                    addr = words[0].getLast20Bytes();
                    permissionId = words[1].intValueSafe();
                    data = words[2].data;
                    tronAddr = utils_1.convertToTronAddress(addr);
                    combine = buffer_1.Buffer.concat([tronAddr, utils_1.bufferFromInt(permissionId), data]);
                    hash = util_1.sha256(combine);
                    signatures = utils_1.extractBytesArray(words, words[3].intValueSafe() / dataWord_1.DataWord.WORD_SIZE, rawData);
                    if (signatures.length == 0 || signatures.length > MAX_SIZE) {
                        return [2 /*return*/, {
                                gasUsed: gasUsed,
                                returnValue: buffer_1.Buffer.alloc(dataWord_1.DataWord.WORD_SIZE, 0),
                            }];
                    }
                    address = new util_1.Address(addr);
                    return [4 /*yield*/, vm.stateManager.getAccount(address)];
                case 1:
                    account = _b.sent();
                    if (account) {
                        try {
                            permission = account.getPermissionById(permissionId);
                            if (permission) {
                                totalWeight = 0;
                                executedSignList = new Set();
                                try {
                                    for (signatures_1 = __values(signatures), signatures_1_1 = signatures_1.next(); !signatures_1_1.done; signatures_1_1 = signatures_1.next()) {
                                        sign = signatures_1_1.value;
                                        signHexStr = sign.toString('hex');
                                        if (executedSignList.has(signHexStr)) {
                                            continue;
                                        }
                                        recoveredAddr = utils_1.recoverAddrBySign(sign, hash);
                                        weight = getWeight(permission, recoveredAddr);
                                        if (weight == 0) {
                                            return [2 /*return*/, {
                                                    gasUsed: gasUsed,
                                                    returnValue: buffer_1.Buffer.alloc(dataWord_1.DataWord.WORD_SIZE, 0),
                                                }];
                                        }
                                        totalWeight += weight;
                                        executedSignList.add(signHexStr);
                                    }
                                }
                                catch (e_1_1) { e_1 = { error: e_1_1 }; }
                                finally {
                                    try {
                                        if (signatures_1_1 && !signatures_1_1.done && (_a = signatures_1.return)) _a.call(signatures_1);
                                    }
                                    finally { if (e_1) throw e_1.error; }
                                }
                                if (totalWeight >= permission.threshold) {
                                    returnValue = buffer_1.Buffer.alloc(dataWord_1.DataWord.WORD_SIZE, 0);
                                    returnValue[dataWord_1.DataWord.WORD_SIZE - 1] = 1;
                                    return [2 /*return*/, {
                                            gasUsed: gasUsed,
                                            returnValue: returnValue,
                                        }];
                                }
                            }
                        }
                        catch (e) {
                            // ignore
                        }
                    }
                    returnData = buffer_1.Buffer.alloc(dataWord_1.DataWord.WORD_SIZE, 0);
                    return [2 /*return*/, {
                            gasUsed: gasUsed,
                            returnValue: returnData,
                        }];
            }
        });
    });
}
exports.default = default_1;
function getWeight(permission, address) {
    var e_2, _a;
    var keys = permission.keys;
    try {
        for (var keys_1 = __values(keys), keys_1_1 = keys_1.next(); !keys_1_1.done; keys_1_1 = keys_1.next()) {
            var key = keys_1_1.value;
            if (dataWord_1.DataWord.equalAddressByteArray(key.address, address)) {
                return key.weight;
            }
        }
    }
    catch (e_2_1) { e_2 = { error: e_2_1 }; }
    finally {
        try {
            if (keys_1_1 && !keys_1_1.done && (_a = keys_1.return)) _a.call(keys_1);
        }
        finally { if (e_2) throw e_2.error; }
    }
    return 0;
}
//# sourceMappingURL=0a-validate-multi-sign.js.map