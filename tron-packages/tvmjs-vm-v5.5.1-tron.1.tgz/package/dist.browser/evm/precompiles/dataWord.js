"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DataWord = void 0;
var util_1 = require("@tvmjs/util");
var DataWord = /** @class */ (function () {
    function DataWord(buffer) {
        this._data = Buffer.alloc(DataWord.WORD_SIZE);
        buffer.copy(this._data, 0, 0, DataWord.WORD_SIZE);
        return this;
    }
    DataWord.parseArray = function (data) {
        var len = data.length / DataWord.WORD_SIZE;
        var words = new Array(len);
        for (var i = 0; i < len; ++i) {
            var start = i * DataWord.WORD_SIZE;
            var buffer = data.slice(start, start + DataWord.WORD_SIZE);
            words[i] = new DataWord(buffer);
        }
        return words;
    };
    Object.defineProperty(DataWord.prototype, "data", {
        get: function () {
            return this._data;
        },
        enumerable: false,
        configurable: true
    });
    DataWord.prototype.intValueSafe = function () {
        var firstNonZero = this._data.findIndex(function (ele) { return ele != 0; });
        var bytesOccupied = 0;
        if (firstNonZero != -1) {
            bytesOccupied = DataWord.WORD_SIZE - firstNonZero + 1;
        }
        var intValue = this.intValue();
        if (bytesOccupied > 4 || intValue < 0) {
            return new util_1.BN(2).pow(new util_1.BN(256)).sub(new util_1.BN(1)).toNumber();
        }
        return intValue;
    };
    DataWord.prototype.intValue = function () {
        var intVal = 0;
        this._data.forEach(function (ele) {
            intVal = (intVal << 8) + (ele & 0xff);
        });
        return intVal;
    };
    DataWord.equalAddressByteArray = function (arr1, arr2) {
        if (arr1 === arr2) {
            return true;
        }
        if (arr1.length < 20 || arr2.length < 20) {
            return false;
        }
        var i = arr1.length - 20;
        var j = arr2.length - 20;
        for (; i < arr1.length && j < arr2.length; ++i, ++j) {
            if (arr1[i] != arr2[j]) {
                return false;
            }
        }
        return true;
    };
    DataWord.prototype.getLast20Bytes = function () {
        var result = Buffer.alloc(20);
        this._data.copy(result, 0, 12, DataWord.WORD_SIZE);
        return result;
    };
    DataWord.WORD_SIZE = 32;
    return DataWord;
}());
exports.DataWord = DataWord;
//# sourceMappingURL=dataWord.js.map